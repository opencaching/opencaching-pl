-- phpMyAdmin SQL Dump
-- version 3.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 06 Sie 2009, 22:07
-- Wersja serwera: 5.0.51
-- Wersja PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Baza danych: `ocpl`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `bulletins`
--

CREATE TABLE IF NOT EXISTS `bulletins` (
  `id` int(11) NOT NULL auto_increment,
  `content` text NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `sent` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `caches`
--

CREATE TABLE IF NOT EXISTS `caches` (
  `cache_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) default NULL,
  `name` varchar(255) default NULL,
  `longitude` double default NULL,
  `latitude` double default NULL,
  `last_modified` datetime default NULL,
  `date_created` datetime default NULL,
  `type` int(11) default NULL,
  `status` int(11) default NULL,
  `country` char(2) default NULL,
  `date_hidden` datetime default NULL,
  `founds` int(11) default NULL,
  `notfounds` int(11) default NULL,
  `notes` int(11) default NULL,
  `images` int(11) default NULL,
  `last_found` datetime default NULL,
  `desc_languages` varchar(60) default NULL,
  `size` int(11) default NULL,
  `difficulty` int(11) default NULL,
  `terrain` int(11) default NULL,
  `uuid` varchar(36) default NULL,
  `watcher` int(11) default NULL,
  `logpw` varchar(20) default NULL,
  `picturescount` int(11) NOT NULL default '0',
  `search_time` double default NULL,
  `way_length` double default NULL,
  `wp_gc` varchar(7) NOT NULL,
  `wp_nc` varchar(6) NOT NULL,
  `wp_oc` varchar(6) default NULL,
  `default_desclang` char(2) NOT NULL,
  `date_activate` datetime default NULL,
  `topratings` int(11) NOT NULL default '0',
  `ignorer_count` int(11) default NULL,
  `node` tinyint(4) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `score` float(2,1) NOT NULL default '0.0',
  PRIMARY KEY  (`cache_id`),
  UNIQUE KEY `wp_oc` (`wp_oc`),
  KEY `longitude` (`longitude`,`latitude`),
  KEY `date_created` (`date_created`),
  KEY `latitude` (`latitude`),
  KEY `country` (`country`),
  KEY `status` (`status`,`date_activate`),
  KEY `last_modified` (`last_modified`),
  KEY `score` (`score`),
  KEY `type` (`type`),
  KEY `size` (`size`),
  KEY `difficulty` (`difficulty`),
  KEY `terrain` (`terrain`),
  KEY `name` (`name`),
  KEY `votes` (`votes`),
  KEY `picturescount` (`picturescount`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6927 ;

--
-- Triggers `caches`
--
DROP TRIGGER IF EXISTS `ocpl`.`cachesAfterInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cachesAfterInsert` AFTER INSERT ON `ocpl`.`caches`
 FOR EACH ROW BEGIN
      INSERT IGNORE INTO `cache_coordinates` (`cache_id`, `date_modified`, `longitude`, `latitude`) 
                                      VALUES (NEW.`cache_id`, NOW(), NEW.`longitude`, NEW.`latitude`);
      INSERT IGNORE INTO `cache_countries` (`cache_id`, `date_modified`, `country`) 
                                      VALUES (NEW.`cache_id`, NOW(), NEW.`country`);
      UPDATE `user`, (SELECT COUNT(*) AS `hidden_count` FROM `caches` WHERE `user_id`=NEW.`user_id` AND `status` IN (1, 2, 3)) AS `c` SET `user`.`hidden_count`=`c`.`hidden_count` WHERE `user`.`user_id`=NEW.`user_id`;
    END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `ocpl`.`cachesAfterUpdate`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cachesAfterUpdate` AFTER UPDATE ON `ocpl`.`caches`
 FOR EACH ROW BEGIN
      IF NEW.`longitude` != OLD.`longitude` OR NEW.`latitude` != OLD.`latitude` THEN
        INSERT IGNORE INTO `cache_coordinates` (`cache_id`, `date_modified`, `longitude`, `latitude`)
                VALUES (NEW.`cache_id`, NOW(), NEW.`longitude`, NEW.`latitude`);
      END IF;
      IF NEW.`country` != OLD.`country` THEN
        INSERT IGNORE INTO `cache_countries` (`cache_id`, `date_modified`, `country`)
                VALUES (NEW.`cache_id`, NOW(), NEW.`country`);
      END IF;
      IF NEW.`status` != OLD.`status` OR NEW.`user_id` != OLD.`user_id` THEN
        UPDATE `user`, (SELECT COUNT(*) AS `hidden_count` FROM `caches` WHERE `user_id`=NEW.`user_id` AND `status` IN (1, 2, 3)) AS `c` SET `user`.`hidden_count`=`c`.`hidden_count` WHERE `user`.`user_id`=NEW.`user_id`;
        IF NEW.`user_id` != OLD.`user_id` THEN
          UPDATE `user`, (SELECT COUNT(*) AS `hidden_count` FROM `caches` WHERE `user_id`=OLD.`user_id` AND `status` IN (1, 2, 3)) AS `c` SET `user`.`hidden_count`=`c`.`hidden_count` WHERE `user`.`user_id`=OLD.`user_id`;
        END IF;
      END IF;
    END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `ocpl`.`cachesAfterDelete`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cachesAfterDelete` AFTER DELETE ON `ocpl`.`caches`
 FOR EACH ROW BEGIN
      DELETE FROM `cache_coordinates` WHERE `cache_id`=OLD.`cache_id`;
      DELETE FROM `cache_countries` WHERE `cache_id`=OLD.`cache_id`;
      UPDATE `user`, (SELECT COUNT(*) AS `hidden_count` FROM `caches` WHERE `user_id`=OLD.`user_id` AND `status` IN (1, 2, 3)) AS `c` SET `user`.`hidden_count`=`c`.`hidden_count` WHERE `user`.`user_id`=OLD.`user_id`;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `caches_attributes`
--

CREATE TABLE IF NOT EXISTS `caches_attributes` (
  `cache_id` int(11) NOT NULL,
  `attrib_id` int(11) NOT NULL,
  PRIMARY KEY  (`cache_id`,`attrib_id`),
  KEY `attrib_id` (`attrib_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_arch`
--

CREATE TABLE IF NOT EXISTS `cache_arch` (
  `cache_id` int(11) NOT NULL,
  `step` int(11) NOT NULL,
  PRIMARY KEY  (`cache_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin2;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_attrib`
--

CREATE TABLE IF NOT EXISTS `cache_attrib` (
  `id` int(11) NOT NULL default '0',
  `language` char(2) NOT NULL,
  `text_short` varchar(20) NOT NULL,
  `text_long` varchar(60) NOT NULL,
  `icon_large` varchar(60) NOT NULL,
  `icon_no` varchar(60) NOT NULL,
  `icon_undef` varchar(60) NOT NULL,
  `category` tinyint(2) NOT NULL default '0',
  `default` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`language`,`id`),
  KEY `category` (`category`,`id`),
  KEY `default` (`default`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_coordinates`
--

CREATE TABLE IF NOT EXISTS `cache_coordinates` (
  `id` int(11) NOT NULL auto_increment,
  `cache_id` int(11) NOT NULL,
  `date_modified` datetime NOT NULL,
  `longitude` double NOT NULL,
  `latitude` double NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cache_id` (`cache_id`,`date_modified`),
  KEY `longitude` (`longitude`),
  KEY `latitude` (`latitude`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13336 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_countries`
--

CREATE TABLE IF NOT EXISTS `cache_countries` (
  `id` int(11) NOT NULL auto_increment,
  `cache_id` int(11) NOT NULL,
  `date_modified` datetime NOT NULL,
  `country` char(2) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `cache_id` (`cache_id`,`date_modified`),
  KEY `country` (`country`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6954 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_desc`
--

CREATE TABLE IF NOT EXISTS `cache_desc` (
  `id` int(11) NOT NULL auto_increment,
  `cache_id` int(11) default NULL,
  `language` char(2) default NULL,
  `desc` mediumtext,
  `desc_html` tinyint(1) NOT NULL default '0',
  `desc_htmledit` tinyint(1) NOT NULL default '0',
  `hint` mediumtext,
  `short_desc` varchar(120) default NULL,
  `date_created` datetime NOT NULL,
  `last_modified` datetime default NULL,
  `uuid` varchar(36) default NULL,
  `node` tinyint(4) NOT NULL default '0',
  `rr_comment` mediumtext NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `cache_id` (`cache_id`,`language`),
  KEY `last_modified` (`last_modified`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7405 ;

--
-- Triggers `cache_desc`
--
DROP TRIGGER IF EXISTS `ocpl`.`cacheDescBeforeInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheDescBeforeInsert` BEFORE INSERT ON `ocpl`.`cache_desc`
 FOR EACH ROW BEGIN
      SET NEW.`date_created`=NOW();
    END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `ocpl`.`cacheDescAfterInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheDescAfterInsert` AFTER INSERT ON `ocpl`.`cache_desc`
 FOR EACH ROW BEGIN
      UPDATE `caches`, (SELECT `cache_id`, GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `lang` FROM `cache_desc` GROUP BY `cache_id`) AS `tbl2` SET `caches`.`desc_languages`=`tbl2`.`lang` WHERE `caches`.`cache_id`=`tbl2`.`cache_id` AND `tbl2`.`cache_id`=NEW.`cache_id`;
    END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `ocpl`.`cacheDescAfterUpdate`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheDescAfterUpdate` AFTER UPDATE ON `ocpl`.`cache_desc`
 FOR EACH ROW BEGIN
      IF OLD.`cache_id` != NEW.`cache_id` OR OLD.`language` != NEW.`language` THEN
        UPDATE `caches`, (SELECT `cache_id`, GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `lang` FROM `cache_desc` GROUP BY `cache_id`) AS `tbl2` SET `caches`.`desc_languages`=`tbl2`.`lang` WHERE `caches`.`cache_id`=`tbl2`.`cache_id` AND `tbl2`.`cache_id`=NEW.`cache_id`;
        IF OLD.`cache_id` != NEW.`cache_id` THEN
          UPDATE `caches`, (SELECT `cache_id`, GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `lang` FROM `cache_desc` GROUP BY `cache_id`) AS `tbl2` SET `caches`.`desc_languages`=`tbl2`.`lang` WHERE `caches`.`cache_id`=`tbl2`.`cache_id` AND `tbl2`.`cache_id`=OLD.`cache_id`;
        END IF;
      END IF;
    END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `ocpl`.`cacheDescAfterDelete`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheDescAfterDelete` AFTER DELETE ON `ocpl`.`cache_desc`
 FOR EACH ROW BEGIN
      UPDATE `caches`, (SELECT `cache_id`, GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `lang` FROM `cache_desc` GROUP BY `cache_id`) AS `tbl2` SET `caches`.`desc_languages`=`tbl2`.`lang` WHERE `caches`.`cache_id`=`tbl2`.`cache_id` AND `tbl2`.`cache_id`=OLD.`cache_id`; 
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_ignore`
--

CREATE TABLE IF NOT EXISTS `cache_ignore` (
  `cache_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1868 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_location`
--

CREATE TABLE IF NOT EXISTS `cache_location` (
  `cache_id` int(11) NOT NULL,
  `last_modified` datetime NOT NULL,
  `adm1` varchar(120) default NULL,
  `adm2` varchar(120) default NULL,
  `adm3` varchar(120) default NULL,
  PRIMARY KEY  (`cache_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_logs`
--

CREATE TABLE IF NOT EXISTS `cache_logs` (
  `id` int(11) NOT NULL auto_increment,
  `cache_id` int(11) default NULL,
  `user_id` int(11) default NULL,
  `type` int(11) default NULL,
  `date` datetime default NULL,
  `text` mediumtext,
  `text_html` tinyint(1) NOT NULL default '0',
  `text_htmledit` tinyint(1) NOT NULL default '0',
  `last_modified` datetime default NULL,
  `uuid` varchar(36) default NULL,
  `picturescount` int(11) NOT NULL default '0',
  `date_created` datetime NOT NULL default '0000-00-00 00:00:00',
  `owner_notified` int(1) NOT NULL default '0',
  `node` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`),
  KEY `date` (`date`),
  KEY `owner_notified` (`owner_notified`),
  KEY `last_modified` (`last_modified`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=89189 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_maps`
--

CREATE TABLE IF NOT EXISTS `cache_maps` (
  `cache_id` int(11) NOT NULL default '0',
  `last_refresh` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`cache_id`),
  KEY `last_refresh` (`last_refresh`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_rating`
--

CREATE TABLE IF NOT EXISTS `cache_rating` (
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`cache_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Triggers `cache_rating`
--
DROP TRIGGER IF EXISTS `ocpl`.`cacheRatingAfterInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheRatingAfterInsert` AFTER INSERT ON `ocpl`.`cache_rating`
 FOR EACH ROW BEGIN  
      UPDATE `caches` SET `topratings`=(SELECT COUNT(*) FROM `cache_rating` WHERE `cache_rating`.`cache_id`=NEW.`cache_id`) WHERE `cache_id`=NEW.`cache_id`;
    END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `ocpl`.`cacheRatingAfterUpdate`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheRatingAfterUpdate` AFTER UPDATE ON `ocpl`.`cache_rating`
 FOR EACH ROW BEGIN  
      IF OLD.`cache_id`!=NEW.`cache_id` THEN
        UPDATE `caches` SET `topratings`=(SELECT COUNT(*) FROM `cache_rating` WHERE `cache_rating`.`cache_id`=OLD.`cache_id`) WHERE `cache_id`=OLD.`cache_id`;
        UPDATE `caches` SET `topratings`=(SELECT COUNT(*) FROM `cache_rating` WHERE `cache_rating`.`cache_id`=NEW.`cache_id`) WHERE `cache_id`=NEW.`cache_id`;
      END IF;
    END
//
DELIMITER ;
DROP TRIGGER IF EXISTS `ocpl`.`cacheRatingAfterDelete`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheRatingAfterDelete` AFTER DELETE ON `ocpl`.`cache_rating`
 FOR EACH ROW BEGIN
      UPDATE `caches` SET `topratings`=(SELECT COUNT(*) FROM `cache_rating` WHERE `cache_rating`.`cache_id`=OLD.`cache_id`) WHERE `cache_id`=OLD.`cache_id`;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_size`
--

CREATE TABLE IF NOT EXISTS `cache_size` (
  `id` int(11) NOT NULL auto_increment,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_status`
--

CREATE TABLE IF NOT EXISTS `cache_status` (
  `id` int(11) NOT NULL auto_increment,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_type`
--

CREATE TABLE IF NOT EXISTS `cache_type` (
  `id` int(11) NOT NULL auto_increment,
  `sort` int(11) NOT NULL default '100',
  `short` varchar(10) NOT NULL,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  `icon_large` varchar(60) NOT NULL,
  `icon_small` varchar(60) NOT NULL,
  `color` varchar(7) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_visits`
--

CREATE TABLE IF NOT EXISTS `cache_visits` (
  `cache_id` int(11) NOT NULL default '0',
  `user_id_ip` varchar(15) NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  `last_visited` datetime default NULL,
  PRIMARY KEY  (`cache_id`,`user_id_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_watches`
--

CREATE TABLE IF NOT EXISTS `cache_watches` (
  `id` int(11) NOT NULL auto_increment,
  `cache_id` int(11) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  `last_executed` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23944 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `chowner`
--

CREATE TABLE IF NOT EXISTS `chowner` (
  `id` int(11) NOT NULL auto_increment,
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `country_id` int(11) NOT NULL auto_increment,
  `pl` varchar(128) NOT NULL,
  `en` varchar(128) NOT NULL,
  `short` char(2) NOT NULL,
  `list_default_pl` int(1) NOT NULL default '0',
  `sort_pl` varchar(128) NOT NULL,
  `list_default_en` int(1) NOT NULL default '0',
  `sort_en` varchar(128) NOT NULL,
  PRIMARY KEY  (`country_id`),
  UNIQUE KEY `short` (`short`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=235 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `email_user`
--

CREATE TABLE IF NOT EXISTS `email_user` (
  `id` int(11) NOT NULL auto_increment,
  `ipaddress` varchar(20) NOT NULL,
  `date_generated` datetime NOT NULL default '0000-00-00 00:00:00',
  `from_user_id` int(11) NOT NULL default '0',
  `from_email` varchar(60) NOT NULL,
  `to_user_id` int(11) NOT NULL default '0',
  `to_email` varchar(60) NOT NULL,
  `mail_subject` varchar(255) NOT NULL,
  `mail_text` text NOT NULL,
  `send_emailaddress` int(1) NOT NULL default '0',
  `date_sent` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  KEY `date_sent` (`date_sent`),
  KEY `from_user_id` (`from_user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7191 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `foreign_caches`
--

CREATE TABLE IF NOT EXISTS `foreign_caches` (
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) default NULL,
  `username` varchar(90) NOT NULL,
  `name` varchar(255) default NULL,
  `longitude` double default NULL,
  `latitude` double default NULL,
  `last_modified` datetime default NULL,
  `date_created` datetime default NULL,
  `type` int(11) default NULL,
  `status` int(11) default NULL,
  `country` char(2) default NULL,
  `date_hidden` datetime default NULL,
  `founds` int(11) default NULL,
  `notfounds` int(11) default NULL,
  `notes` int(11) default NULL,
  `images` int(11) default NULL,
  `last_found` datetime default NULL,
  `desc_languages` varchar(60) default NULL,
  `size` int(11) default NULL,
  `difficulty` int(11) default NULL,
  `terrain` int(11) default NULL,
  `uuid` varchar(36) default NULL,
  `watcher` int(11) default NULL,
  `logpw` varchar(20) default NULL,
  `picturescount` int(11) NOT NULL default '0',
  `search_time` double default NULL,
  `way_length` double default NULL,
  `wp_gc` varchar(7) NOT NULL,
  `wp_nc` varchar(6) NOT NULL,
  `wp_oc` varchar(6) default NULL,
  `default_desclang` char(2) NOT NULL,
  `date_activate` datetime default NULL,
  `topratings` int(11) NOT NULL default '0',
  `ignorer_count` int(11) default NULL,
  `node` tinyint(4) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `score` float(2,1) NOT NULL default '0.0',
  PRIMARY KEY  (`cache_id`,`node`),
  UNIQUE KEY `wp_oc` (`wp_oc`),
  KEY `longitude` (`longitude`,`latitude`),
  KEY `date_created` (`date_created`),
  KEY `latitude` (`latitude`),
  KEY `country` (`country`),
  KEY `status` (`status`,`date_activate`),
  KEY `last_modified` (`last_modified`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_areas`
--

CREATE TABLE IF NOT EXISTS `geodb_areas` (
  `loc_id` int(11) NOT NULL default '0',
  `area_id` int(11) NOT NULL default '0',
  `polygon_id` int(11) default NULL,
  `pol_seq_no` int(11) NOT NULL default '0',
  `exclude_area` smallint(1) NOT NULL default '0',
  `area_type` int(11) NOT NULL default '0',
  `area_subtype` int(11) default NULL,
  `coord_type` int(11) NOT NULL default '0',
  `coord_subtype` int(11) default NULL,
  `resolution` int(11) NOT NULL default '0',
  `valid_since` date default NULL,
  `date_type_since` int(11) default NULL,
  `valid_until` date NOT NULL default '0000-00-00',
  `date_type_until` int(11) NOT NULL default '0',
  UNIQUE KEY `loc_id` (`loc_id`,`area_id`),
  KEY `areas_loc_id_idx` (`loc_id`),
  KEY `areas_area_id_idx` (`area_id`),
  KEY `areas_pol_id_idx` (`polygon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_changelog`
--

CREATE TABLE IF NOT EXISTS `geodb_changelog` (
  `id` int(11) NOT NULL default '0',
  `datum` date NOT NULL default '0000-00-00',
  `beschreibung` text NOT NULL,
  `autor` varchar(50) NOT NULL default '',
  `version` varchar(8) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_coordinates`
--

CREATE TABLE IF NOT EXISTS `geodb_coordinates` (
  `loc_id` int(11) NOT NULL default '0',
  `lon` double default NULL,
  `lat` double default NULL,
  `coord_type` int(11) NOT NULL default '0',
  `coord_subtype` int(11) default NULL,
  `valid_since` date default NULL,
  `date_type_since` int(11) default NULL,
  `valid_until` date NOT NULL default '0000-00-00',
  `date_type_until` int(11) NOT NULL default '0',
  KEY `coord_loc_id_idx` (`loc_id`),
  KEY `coord_lon_idx` (`lon`),
  KEY `coord_lat_idx` (`lat`),
  KEY `coord_type_idx` (`coord_type`),
  KEY `coord_stype_idx` (`coord_subtype`),
  KEY `coord_since_idx` (`valid_since`),
  KEY `coord_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_floatdata`
--

CREATE TABLE IF NOT EXISTS `geodb_floatdata` (
  `loc_id` int(11) NOT NULL default '0',
  `float_val` double NOT NULL default '0',
  `float_type` int(11) NOT NULL default '0',
  `float_subtype` int(11) default NULL,
  `valid_since` date default NULL,
  `date_type_since` int(11) default NULL,
  `valid_until` date NOT NULL default '0000-00-00',
  `date_type_until` int(11) NOT NULL default '0',
  KEY `float_lid_idx` (`loc_id`),
  KEY `float_val_idx` (`float_val`),
  KEY `float_type_idx` (`float_type`),
  KEY `float_stype_idx` (`float_subtype`),
  KEY `float_since_idx` (`valid_since`),
  KEY `float_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_hierarchies`
--

CREATE TABLE IF NOT EXISTS `geodb_hierarchies` (
  `loc_id` int(11) NOT NULL default '0',
  `level` int(11) NOT NULL default '0',
  `id_lvl1` int(11) NOT NULL default '0',
  `id_lvl2` int(11) default NULL,
  `id_lvl3` int(11) default NULL,
  `id_lvl4` int(11) default NULL,
  `id_lvl5` int(11) default NULL,
  `id_lvl6` int(11) default NULL,
  `id_lvl7` int(11) default NULL,
  `id_lvl8` int(11) default NULL,
  `id_lvl9` int(11) default NULL,
  `valid_since` date default NULL,
  `date_type_since` int(11) default NULL,
  `valid_until` date NOT NULL default '0000-00-00',
  `date_type_until` int(11) NOT NULL default '0',
  KEY `hierarchy_loc_id_idx` (`loc_id`),
  KEY `hierarchy_level_idx` (`level`),
  KEY `hierarchy_lvl1_idx` (`id_lvl1`),
  KEY `hierarchy_lvl2_idx` (`id_lvl2`),
  KEY `hierarchy_lvl3_idx` (`id_lvl3`),
  KEY `hierarchy_lvl4_idx` (`id_lvl4`),
  KEY `hierarchy_lvl5_idx` (`id_lvl5`),
  KEY `hierarchy_lvl6_idx` (`id_lvl6`),
  KEY `hierarchy_lvl7_idx` (`id_lvl7`),
  KEY `hierarchy_lvl8_idx` (`id_lvl8`),
  KEY `hierarchy_lvl9_idx` (`id_lvl9`),
  KEY `hierarchy_since_idx` (`valid_since`),
  KEY `hierarchy_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_intdata`
--

CREATE TABLE IF NOT EXISTS `geodb_intdata` (
  `loc_id` int(11) NOT NULL default '0',
  `int_val` bigint(20) NOT NULL default '0',
  `int_type` int(11) NOT NULL default '0',
  `int_subtype` int(11) default NULL,
  `valid_since` date default NULL,
  `date_type_since` int(11) default NULL,
  `valid_until` date NOT NULL default '0000-00-00',
  `date_type_until` int(11) NOT NULL default '0',
  KEY `int_lid_idx` (`loc_id`),
  KEY `int_val_idx` (`int_val`),
  KEY `int_type_idx` (`int_type`),
  KEY `int_stype_idx` (`int_subtype`),
  KEY `int_since_idx` (`valid_since`),
  KEY `int_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_locations`
--

CREATE TABLE IF NOT EXISTS `geodb_locations` (
  `loc_id` int(11) NOT NULL default '0',
  `loc_type` int(11) NOT NULL default '0',
  PRIMARY KEY  (`loc_id`),
  KEY `loc_type_idx` (`loc_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_polygons`
--

CREATE TABLE IF NOT EXISTS `geodb_polygons` (
  `polygon_id` int(11) NOT NULL default '0',
  `seq_no` int(11) NOT NULL default '0',
  `lon` double NOT NULL default '0',
  `lat` double NOT NULL default '0',
  UNIQUE KEY `polygon_id` (`polygon_id`,`seq_no`),
  KEY `polygons_pid_idx` (`polygon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_search`
--

CREATE TABLE IF NOT EXISTS `geodb_search` (
  `id` int(11) NOT NULL auto_increment,
  `loc_id` int(11) NOT NULL default '0',
  `sort` varchar(255) NOT NULL,
  `simple` varchar(255) NOT NULL,
  `simplehash` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `sort` (`sort`),
  KEY `simple` (`simple`),
  KEY `simplehash` (`simplehash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_textdata`
--

CREATE TABLE IF NOT EXISTS `geodb_textdata` (
  `loc_id` int(11) NOT NULL default '0',
  `text_val` varchar(255) NOT NULL default '',
  `text_type` int(11) NOT NULL default '0',
  `text_locale` varchar(5) default NULL,
  `is_native_lang` smallint(1) default NULL,
  `is_default_name` smallint(1) default NULL,
  `valid_since` date default NULL,
  `date_type_since` int(11) default NULL,
  `valid_until` date NOT NULL default '0000-00-00',
  `date_type_until` int(11) NOT NULL default '0',
  KEY `text_lid_idx` (`loc_id`),
  KEY `text_val_idx` (`text_val`),
  KEY `text_type_idx` (`text_type`),
  KEY `text_locale_idx` (`text_locale`),
  KEY `text_native_idx` (`is_native_lang`),
  KEY `text_default_idx` (`is_default_name`),
  KEY `text_since_idx` (`valid_since`),
  KEY `text_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_type_names`
--

CREATE TABLE IF NOT EXISTS `geodb_type_names` (
  `type_id` int(11) NOT NULL default '0',
  `type_locale` varchar(5) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  UNIQUE KEY `type_id` (`type_id`,`type_locale`),
  KEY `tid_tnames_idx` (`type_id`),
  KEY `locale_tnames_idx` (`type_locale`),
  KEY `name_tnames_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_item`
--

CREATE TABLE IF NOT EXISTS `gk_item` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `description` longtext NOT NULL,
  `userid` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `datemodified` datetime NOT NULL,
  `distancetravelled` float NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `typeid` int(11) NOT NULL,
  `stateid` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_item_type`
--

CREATE TABLE IF NOT EXISTS `gk_item_type` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_item_waypoint`
--

CREATE TABLE IF NOT EXISTS `gk_item_waypoint` (
  `id` int(11) NOT NULL,
  `wp` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`,`wp`),
  KEY `wp` (`wp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_move`
--

CREATE TABLE IF NOT EXISTS `gk_move` (
  `id` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `datemoved` datetime NOT NULL,
  `datelogged` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `comment` longtext NOT NULL,
  `logtypeid` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `itemid` (`itemid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_move_type`
--

CREATE TABLE IF NOT EXISTS `gk_move_type` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_move_waypoint`
--

CREATE TABLE IF NOT EXISTS `gk_move_waypoint` (
  `id` int(11) NOT NULL,
  `wp` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`,`wp`),
  KEY `wp` (`wp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_user`
--

CREATE TABLE IF NOT EXISTS `gk_user` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gns_locations`
--

CREATE TABLE IF NOT EXISTS `gns_locations` (
  `rc` tinyint(4) NOT NULL default '0',
  `ufi` int(11) NOT NULL default '0',
  `uni` int(11) NOT NULL default '0',
  `lat` double NOT NULL default '0',
  `lon` double NOT NULL default '0',
  `dms_lat` int(11) NOT NULL default '0',
  `dms_lon` int(11) NOT NULL default '0',
  `utm` varchar(4) NOT NULL,
  `jog` varchar(7) NOT NULL,
  `fc` char(1) NOT NULL,
  `dsg` varchar(5) NOT NULL,
  `pc` tinyint(4) NOT NULL default '0',
  `cc1` char(2) NOT NULL,
  `adm1` char(2) NOT NULL,
  `adm2` varchar(200) NOT NULL,
  `dim` int(11) NOT NULL default '0',
  `cc2` char(2) NOT NULL,
  `nt` char(1) NOT NULL,
  `lc` char(2) NOT NULL,
  `SHORT_FORM` varchar(128) NOT NULL,
  `GENERIC` varchar(128) NOT NULL,
  `SORT_NAME` varchar(200) NOT NULL,
  `FULL_NAME` varchar(200) NOT NULL,
  `FULL_NAME_ND` varchar(200) NOT NULL,
  `MOD_DATE` date NOT NULL default '0000-00-00',
  `admtxt1` varchar(120) NOT NULL,
  `admtxt3` varchar(120) NOT NULL,
  `admtxt4` varchar(120) NOT NULL,
  `admtxt2` varchar(120) NOT NULL,
  PRIMARY KEY  (`uni`),
  KEY `rc` (`rc`,`fc`,`dsg`,`cc1`),
  KEY `ufi` (`ufi`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gns_search`
--

CREATE TABLE IF NOT EXISTS `gns_search` (
  `id` int(11) NOT NULL auto_increment,
  `uni_id` int(11) NOT NULL default '0',
  `sort` varchar(255) NOT NULL,
  `simple` varchar(255) NOT NULL,
  `simplehash` int(11) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `simplehash` (`simplehash`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=69703 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL auto_increment,
  `short` char(2) NOT NULL,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  `list_default_pl` int(1) NOT NULL default '0',
  `list_default_en` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `short` (`short`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `logentries`
--

CREATE TABLE IF NOT EXISTS `logentries` (
  `id` int(11) NOT NULL auto_increment,
  `module` varchar(30) NOT NULL,
  `eventid` int(11) NOT NULL default '0',
  `userid` int(11) NOT NULL default '0',
  `objectid1` int(11) NOT NULL default '0',
  `objectid2` int(11) NOT NULL default '0',
  `logtext` mediumtext NOT NULL,
  `details` blob NOT NULL,
  `logtime` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=408500 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `logentries_types`
--

CREATE TABLE IF NOT EXISTS `logentries_types` (
  `id` int(11) NOT NULL auto_increment,
  `module` varchar(30) NOT NULL,
  `eventname` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `logins`
--

CREATE TABLE IF NOT EXISTS `logins` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `remote_addr` varchar(15) NOT NULL,
  `success` int(1) NOT NULL default '0',
  `timestamp` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=108912 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `log_types`
--

CREATE TABLE IF NOT EXISTS `log_types` (
  `id` int(11) NOT NULL auto_increment,
  `cache_status` int(1) NOT NULL default '0',
  `permission` char(1) NOT NULL,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  `icon_small` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `log_types_text`
--

CREATE TABLE IF NOT EXISTS `log_types_text` (
  `id` int(11) NOT NULL auto_increment,
  `log_types_id` int(11) NOT NULL default '0',
  `lang` char(2) NOT NULL,
  `text_combo` varchar(255) NOT NULL,
  `text_listing` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `lang` (`lang`,`log_types_id`),
  KEY `log_types_id` (`log_types_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `map_settings`
--

CREATE TABLE IF NOT EXISTS `map_settings` (
  `user_id` int(11) NOT NULL,
  `unknown` int(1) default '1',
  `traditional` int(1) default '1',
  `multicache` int(1) default '1',
  `virtual` int(1) default '1',
  `webcam` int(1) default '1',
  `event` int(1) default '1',
  `quiz` int(1) default '1',
  `math` int(1) default '1',
  `mobile` int(1) default '1',
  `drivein` int(1) default '1',
  `ignored` int(1) default '0',
  `own` int(1) default '1',
  `found` int(1) default '1',
  `notyetfound` int(1) default '1',
  `geokret` int(1) default '1',
  `showsign` int(1) default '0',
  `active` int(1) default '1',
  `notactive` int(1) default '0',
  `maptype` int(1) default '3',
  `cachelimit` int(1) default '4',
  `cachesort` int(1) default '1',
  `archived` int(1) default '0',
  `be_ftf` int(1) default '0',
  `de` int(1) default '1',
  `pl` int(1) default '1',
  `min_score` int(1) NOT NULL default '-3',
  `max_score` int(1) NOT NULL default '3',
  `noscore` int(1) NOT NULL default '1',
  PRIMARY KEY  (`user_id`),
  KEY `min_score` (`min_score`),
  KEY `max_score` (`max_score`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `map_settings_v2`
--

CREATE TABLE IF NOT EXISTS `map_settings_v2` (
  `user_id` int(11) NOT NULL,
  `unknown` int(1) default '1',
  `traditional` int(1) default '1',
  `multicache` int(1) default '1',
  `virtual` int(1) default '1',
  `webcam` int(1) default '1',
  `event` int(1) default '1',
  `quiz` int(1) default '1',
  `math` int(1) default '1',
  `mobile` int(1) default '1',
  `drivein` int(1) default '1',
  `ignored` int(1) default '0',
  `own` int(1) default '1',
  `found` int(1) default '1',
  `notyetfound` int(1) default '1',
  `geokret` int(1) default '1',
  `showsign` int(1) default '0',
  `active` int(1) default '0',
  `notactive` int(1) default '1',
  `maptype` int(1) default '3',
  `cachelimit` int(1) default '4',
  `cachesort` int(1) default '1',
  `archived` int(1) default '0',
  `be_ftf` int(1) default '0',
  `de` int(1) default '1',
  `pl` int(1) default '1',
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL auto_increment,
  `date_posted` datetime NOT NULL default '0000-00-00 00:00:00',
  `content` text NOT NULL,
  `topic` int(11) NOT NULL default '0',
  `display` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=51 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `news_topics`
--

CREATE TABLE IF NOT EXISTS `news_topics` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `nodes`
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` tinyint(4) NOT NULL auto_increment,
  `name` varchar(60) NOT NULL,
  `url` varchar(260) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `notify_waiting`
--

CREATE TABLE IF NOT EXISTS `notify_waiting` (
  `id` int(11) NOT NULL auto_increment,
  `cache_id` int(11) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  `type` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `cache_user` (`cache_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=122204 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `object_types`
--

CREATE TABLE IF NOT EXISTS `object_types` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `pictures`
--

CREATE TABLE IF NOT EXISTS `pictures` (
  `id` int(11) NOT NULL auto_increment,
  `uuid` varchar(36) NOT NULL,
  `url` varchar(255) NOT NULL,
  `last_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `title` varchar(250) default NULL,
  `description` text,
  `desc_html` int(11) NOT NULL default '0',
  `date_created` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_url_check` datetime NOT NULL default '0000-00-00 00:00:00',
  `object_id` int(11) NOT NULL default '0',
  `object_type` int(11) NOT NULL default '0',
  `user_id` int(11) NOT NULL default '0',
  `thumb_url` varchar(255) NOT NULL,
  `thumb_last_generated` datetime NOT NULL default '0000-00-00 00:00:00',
  `spoiler` int(1) NOT NULL default '0',
  `local` int(1) NOT NULL default '1',
  `unknown_format` int(1) NOT NULL default '0',
  `display` int(1) NOT NULL default '1',
  `node` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `last_modified` (`last_modified`),
  KEY `url` (`url`),
  KEY `title` (`title`),
  KEY `object_id` (`object_id`),
  KEY `uuid` (`uuid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29631 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `queries`
--

CREATE TABLE IF NOT EXISTS `queries` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `name` varchar(60) NOT NULL,
  `options` blob NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `filters_count` int(11) NOT NULL default '0',
  `last_queried` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UUID` (`uuid`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2974000 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `removed_objects`
--

CREATE TABLE IF NOT EXISTS `removed_objects` (
  `id` int(11) NOT NULL auto_increment,
  `localID` int(11) NOT NULL default '0',
  `uuid` varchar(36) NOT NULL,
  `type` int(1) NOT NULL default '0',
  `removed_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `node` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `UUID` (`uuid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8464 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `cache_id` int(11) NOT NULL,
  `type` tinyint(10) NOT NULL default '4',
  `text` varchar(4096) NOT NULL,
  `note` text NOT NULL,
  `submit_date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `status` tinyint(3) NOT NULL default '0',
  `changed_by` int(11) NOT NULL default '0',
  `changed_date` timestamp NULL default NULL,
  `responsible_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=260 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `rr_ocpl_candidates_2009`
--

CREATE TABLE IF NOT EXISTS `rr_ocpl_candidates_2009` (
  `candidate_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `username` varchar(60) collate utf8_polish_ci NOT NULL,
  `city` varchar(60) collate utf8_polish_ci NOT NULL,
  PRIMARY KEY  (`candidate_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `rr_ocpl_vote_2009`
--

CREATE TABLE IF NOT EXISTS `rr_ocpl_vote_2009` (
  `vote_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  PRIMARY KEY  (`vote_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=936 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `scores`
--

CREATE TABLE IF NOT EXISTS `scores` (
  `id` int(11) NOT NULL auto_increment,
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`),
  KEY `score` (`score`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32792 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_doubles`
--

CREATE TABLE IF NOT EXISTS `search_doubles` (
  `hash` int(10) unsigned NOT NULL,
  `word` varchar(30) NOT NULL,
  `simple` varchar(30) NOT NULL,
  PRIMARY KEY  (`hash`,`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_ignore`
--

CREATE TABLE IF NOT EXISTS `search_ignore` (
  `word` varchar(30) NOT NULL,
  PRIMARY KEY  (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_index`
--

CREATE TABLE IF NOT EXISTS `search_index` (
  `object_type` tinyint(4) NOT NULL,
  `cache_id` int(11) NOT NULL,
  `hash` int(10) unsigned NOT NULL,
  `count` tinyint(4) unsigned NOT NULL default '0',
  PRIMARY KEY  (`object_type`,`cache_id`,`hash`),
  KEY `object_type` (`object_type`,`hash`,`cache_id`,`count`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_index_times`
--

CREATE TABLE IF NOT EXISTS `search_index_times` (
  `object_type` tinyint(4) NOT NULL,
  `object_id` int(11) NOT NULL,
  `last_refresh` datetime NOT NULL,
  PRIMARY KEY  (`object_type`,`object_id`),
  KEY `last_refresh` (`last_refresh`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_words`
--

CREATE TABLE IF NOT EXISTS `search_words` (
  `id` bigint(20) unsigned NOT NULL auto_increment,
  `word` varchar(255) NOT NULL,
  `simple` varchar(30) NOT NULL,
  `hash` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `hash` (`hash`,`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `statpics`
--

CREATE TABLE IF NOT EXISTS `statpics` (
  `id` int(11) NOT NULL auto_increment,
  `tplpath` varchar(200) NOT NULL,
  `previewpath` varchar(200) NOT NULL,
  `description` varchar(80) NOT NULL,
  `maxtextwidth` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sysconfig`
--

CREATE TABLE IF NOT EXISTS `sysconfig` (
  `name` varchar(60) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_cron`
--

CREATE TABLE IF NOT EXISTS `sys_cron` (
  `name` varchar(60) NOT NULL,
  `last_run` datetime NOT NULL,
  PRIMARY KEY  (`name`),
  KEY `last_run` (`last_run`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_logins`
--

CREATE TABLE IF NOT EXISTS `sys_logins` (
  `id` int(11) NOT NULL auto_increment,
  `remote_addr` varchar(15) NOT NULL,
  `success` tinyint(1) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `timestamp` (`timestamp`),
  KEY `remote_addr` (`remote_addr`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=249569 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_menu`
--

CREATE TABLE IF NOT EXISTS `sys_menu` (
  `id` smallint(6) NOT NULL auto_increment,
  `id_string` varchar(80) NOT NULL,
  `title` varchar(80) NOT NULL,
  `menustring` varchar(80) NOT NULL,
  `access` tinyint(4) NOT NULL,
  `href` varchar(80) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `parent` smallint(6) NOT NULL,
  `position` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `id_string` (`id_string`),
  KEY `parent` (`parent`,`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_sessions`
--

CREATE TABLE IF NOT EXISTS `sys_sessions` (
  `uuid` varchar(36) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permanent` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY  (`uuid`),
  KEY `last_login` (`last_login`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_temptables`
--

CREATE TABLE IF NOT EXISTS `sys_temptables` (
  `threadid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY  (`threadid`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL auto_increment,
  `username` varchar(60) character set utf8 collate utf8_polish_ci default NULL,
  `password` varchar(512) default NULL,
  `email` varchar(60) default NULL,
  `latitude` double default NULL,
  `longitude` double default NULL,
  `last_modified` datetime default NULL,
  `login_faults` int(11) default NULL,
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `login_id` varchar(13) default NULL,
  `is_active_flag` int(11) default NULL,
  `was_loggedin` int(11) default NULL,
  `country` char(2) default NULL,
  `pmr_flag` int(11) default NULL,
  `new_pw_code` varchar(13) default NULL,
  `new_pw_date` int(11) default NULL,
  `date_created` datetime default NULL,
  `new_email_code` varchar(13) default NULL,
  `new_email_date` int(11) default NULL,
  `new_email` varchar(60) default NULL,
  `post_news` int(11) default NULL,
  `hidden_count` int(11) default '0',
  `log_notes_count` int(11) default '0',
  `founds_count` int(11) default '0',
  `notfounds_count` int(11) default '0',
  `uuid` varchar(36) default NULL,
  `cache_watches` int(11) default NULL,
  `permanent_login_flag` int(11) default NULL,
  `watchmail_mode` int(11) NOT NULL default '1',
  `watchmail_hour` int(11) NOT NULL default '0',
  `watchmail_nextmail` datetime NOT NULL default '0000-00-00 00:00:00',
  `watchmail_day` int(11) NOT NULL default '0',
  `activation_code` varchar(13) NOT NULL,
  `statpic_logo` int(11) NOT NULL default '0',
  `statpic_text` varchar(30) NOT NULL default 'Opencaching',
  `cache_ignores` int(11) default '0',
  `no_htmledit_flag` tinyint(1) NOT NULL default '0',
  `notify_radius` int(11) NOT NULL default '0',
  `admin` tinyint(1) NOT NULL default '0',
  `node` tinyint(4) NOT NULL default '0',
  `stat_ban` tinyint(1) NOT NULL default '0',
  `description` varchar(1024) default NULL,
  `rules_confirmed` int(1) NOT NULL default '0',
  `get_bulletin` tinyint(1) NOT NULL default '1',
  `ozi_filips` varchar(255) default NULL,
  `hide_flag` int(1) NOT NULL default '0',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `notify_radius` (`notify_radius`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10730 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `watches_notified`
--

CREATE TABLE IF NOT EXISTS `watches_notified` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `object_id` int(11) NOT NULL default '0',
  `object_type` int(11) NOT NULL default '0',
  `date_processed` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user_id` (`user_id`,`object_id`,`object_type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=293435 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `watches_waiting`
--

CREATE TABLE IF NOT EXISTS `watches_waiting` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `object_id` int(11) NOT NULL default '0',
  `object_type` int(11) NOT NULL default '0',
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `watchtext` mediumtext NOT NULL,
  `watchtype` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=300639 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `watches_waitingtypes`
--

CREATE TABLE IF NOT EXISTS `watches_waitingtypes` (
  `id` int(11) NOT NULL auto_increment,
  `watchtype` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `xmlsession`
--

CREATE TABLE IF NOT EXISTS `xmlsession` (
  `id` int(11) NOT NULL auto_increment,
  `last_use` datetime NOT NULL default '0000-00-00 00:00:00',
  `users` int(11) NOT NULL default '0',
  `caches` int(11) NOT NULL default '0',
  `cachedescs` int(11) NOT NULL default '0',
  `cachelogs` int(11) NOT NULL default '0',
  `pictures` int(11) NOT NULL default '0',
  `removedobjects` int(11) NOT NULL default '0',
  `modified_since` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_created` datetime NOT NULL default '0000-00-00 00:00:00',
  `cleaned` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=74599 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `xmlsession_data`
--

CREATE TABLE IF NOT EXISTS `xmlsession_data` (
  `session_id` int(11) NOT NULL default '0',
  `object_type` int(11) NOT NULL default '0',
  `object_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`session_id`,`object_type`,`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
