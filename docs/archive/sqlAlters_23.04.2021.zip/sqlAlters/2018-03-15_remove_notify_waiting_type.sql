-- 2018-03-15
-- @author: deg-pl

-- nofity_waiting.type is not used anymore
ALTER TABLE `notify_waiting` DROP `type`;