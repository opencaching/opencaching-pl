-- 2018-02-01
-- @author: rapotek

--
-- watches_notified table is no longer used in runwatch processing
-- and never used anywhere else
--
DROP TABLE IF EXISTS watches_notified;

