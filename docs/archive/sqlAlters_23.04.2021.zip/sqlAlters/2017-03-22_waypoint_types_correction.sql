-- 2017-03-22: Form select default displayed value
-- @author: andrixnet

-- this indicator value is no longer necessary

DELETE FROM waypoint_type
    WHERE id=-1;
