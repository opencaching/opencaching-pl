-- 2017-04-18 Add waypoint_type "Trailhead" to DB
-- @author: Harrie Klomp


INSERT INTO `waypoint_type` (`id`, `pl`, `en`, `nl`, `de`, `ro`, `icon`) VALUES (6, 'Początek ścieżki', 'Trailhead', 'Begin wandelpad', 'Anfang wanderpfad', 'Început de traseu', 'images/waypoints/wp_trailhead.png')
