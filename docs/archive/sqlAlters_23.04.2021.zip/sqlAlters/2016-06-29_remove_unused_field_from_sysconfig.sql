--
-- Related with: https://github.com/opencaching/opencaching-pl/issues/692
--
DELETE FROM `sysconfig` WHERE `sysconfig`.`name` = "hidden_for_approval"