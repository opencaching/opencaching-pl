--
-- Table foreign_caches is obsolete for many years
-- This was used only by map_v2 - now this code is removed
-- This table can be safety dropped
--

DROP TABLE foreign_caches;