-- 2018-10-03
-- @author: kojoty

-- map-v3 is removed - setting are no more needed

DROP TABLE map_settings;
