-- 2017.08.09 deg
--

-- Remove bulletin funcions (see issue #1113)
--

DROP TABLE bulletins