--
-- Author: mzylowski
--

-- Remove table related with never finished medals system
DROP TABLE IF EXISTS medals;

