-- 2018-09-17
-- @author: kojoty

-- map-v2 is removed - setting are no more needed

DROP TABLE map_settings_v2;
