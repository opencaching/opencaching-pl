<?php
tpl_set_var('hiddens', '0');
tpl_set_var('total_hiddens', '0');
tpl_set_var('founds', '0');
tpl_set_var('users', '2');
?>