<img src="http://maps.google.com/maps/api/staticmap?center=52.130000,19.200000&zoom=5&size=250x260&maptype=roadmap&key=ABQIAAAA4DS0L5IhPNkkzhAejJ1YghQmw8g3SyoYQoey3nQkQjZ-xBIKWxQBStwSQ5otzHFYPFzfrBNiNotrGQ&sensor=
false" id="main-cachemap" name="main-cachemap" alt="{{map}}" />
