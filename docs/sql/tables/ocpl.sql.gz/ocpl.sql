-- phpMyAdmin SQL Dump
-- version 2.11.3deb1ubuntu1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 09 Maj 2012, 07:21
-- Wersja serwera: 5.1.58
-- Wersja PHP: 5.3.6-6~dotdeb.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Baza danych: `ocpl`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `approval_status`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 09 Maj 2012, 00:03
--

CREATE TABLE IF NOT EXISTS `approval_status` (
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `date_approval` datetime DEFAULT NULL,
  PRIMARY KEY (`cache_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `bulletins`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 24 Lut 2011, 12:25
--

CREATE TABLE IF NOT EXISTS `bulletins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) NOT NULL,
  `sent` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `caches`
--
-- Utworzenie: 10 Kwi 2012, 09:34
--

CREATE TABLE IF NOT EXISTS `caches` (
  `cache_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `okapi_syncbase` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` datetime DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `date_hidden` datetime DEFAULT NULL,
  `founds` int(11) DEFAULT NULL,
  `notfounds` int(11) DEFAULT NULL,
  `notes` int(11) DEFAULT NULL,
  `images` int(11) DEFAULT NULL,
  `last_found` datetime DEFAULT NULL,
  `desc_languages` varchar(60) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `difficulty` int(11) DEFAULT NULL,
  `terrain` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `watcher` int(11) DEFAULT NULL,
  `logpw` varchar(20) DEFAULT NULL,
  `picturescount` int(11) NOT NULL DEFAULT '0',
  `mp3count` int(11) NOT NULL DEFAULT '0',
  `search_time` double DEFAULT NULL,
  `way_length` double DEFAULT NULL,
  `wp_gc` varchar(7) NOT NULL,
  `wp_nc` varchar(6) NOT NULL,
  `wp_ge` varchar(7) NOT NULL COMMENT 'GPSGames',
  `wp_tc` varchar(7) NOT NULL COMMENT 'TerraCaching',
  `wp_oc` varchar(6) DEFAULT NULL,
  `default_desclang` char(2) NOT NULL,
  `date_activate` datetime DEFAULT NULL,
  `topratings` int(11) NOT NULL DEFAULT '0',
  `ignorer_count` int(11) DEFAULT NULL,
  `node` tinyint(4) NOT NULL DEFAULT '0',
  `votes` int(11) NOT NULL DEFAULT '0',
  `score` float(2,1) NOT NULL DEFAULT '0.0',
  `need_npa_recalc` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cache_id`),
  UNIQUE KEY `wp_oc` (`wp_oc`),
  KEY `longitude` (`longitude`,`latitude`),
  KEY `date_created` (`date_created`),
  KEY `latitude` (`latitude`),
  KEY `country` (`country`),
  KEY `status` (`status`,`date_activate`),
  KEY `last_modified` (`last_modified`),
  KEY `score` (`score`),
  KEY `type` (`type`),
  KEY `size` (`size`),
  KEY `difficulty` (`difficulty`),
  KEY `terrain` (`terrain`),
  KEY `name` (`name`),
  KEY `votes` (`votes`),
  KEY `picturescount` (`picturescount`),
  KEY `user_id` (`user_id`),
  KEY `need_npa_recalc` (`need_npa_recalc`),
  KEY `okapi_syncbase` (`okapi_syncbase`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

--
-- Triggers `caches`
--
DROP TRIGGER `ocpl`.`cachesBeforeInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cachesBeforeInsert` BEFORE INSERT ON `ocpl`.`caches`
 FOR EACH ROW BEGIN 
						SET NEW.`need_npa_recalc`=1;
					END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cachesAfterInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cachesAfterInsert` AFTER INSERT ON `ocpl`.`caches`
 FOR EACH ROW BEGIN
      INSERT IGNORE INTO `cache_coordinates` (`cache_id`, `date_modified`, `longitude`, `latitude`) 
                                      VALUES (NEW.`cache_id`, NOW(), NEW.`longitude`, NEW.`latitude`);
      INSERT IGNORE INTO `cache_countries` (`cache_id`, `date_modified`, `country`) 
                                      VALUES (NEW.`cache_id`, NOW(), NEW.`country`);
      UPDATE `user`, (SELECT COUNT(*) AS `hidden_count` FROM `caches` WHERE `user_id`=NEW.`user_id` AND `status` IN (1, 2, 3)) AS `c` SET `user`.`hidden_count`=`c`.`hidden_count` WHERE `user`.`user_id`=NEW.`user_id`;
    END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cachesBeforeUpdate`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cachesBeforeUpdate` BEFORE UPDATE ON `ocpl`.`caches`
 FOR EACH ROW BEGIN 
						IF OLD.`longitude`!=NEW.`longitude` OR 
						   OLD.`latitude`!=NEW.`latitude` THEN
							SET NEW.`need_npa_recalc`=1;
						END IF;
					END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cachesAfterUpdate`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cachesAfterUpdate` AFTER UPDATE ON `ocpl`.`caches`
 FOR EACH ROW BEGIN
      IF NEW.`longitude` != OLD.`longitude` OR NEW.`latitude` != OLD.`latitude` THEN
        INSERT IGNORE INTO `cache_coordinates` (`cache_id`, `date_modified`, `longitude`, `latitude`)
                VALUES (NEW.`cache_id`, NOW(), NEW.`longitude`, NEW.`latitude`);
      END IF;
      IF NEW.`country` != OLD.`country` THEN
        INSERT IGNORE INTO `cache_countries` (`cache_id`, `date_modified`, `country`)
                VALUES (NEW.`cache_id`, NOW(), NEW.`country`);
      END IF;
      IF NEW.`status` != OLD.`status` OR NEW.`user_id` != OLD.`user_id` THEN
        UPDATE `user`, (SELECT COUNT(*) AS `hidden_count` FROM `caches` WHERE `user_id`=NEW.`user_id` AND `status` IN (1, 2, 3)) AS `c` SET `user`.`hidden_count`=`c`.`hidden_count` WHERE `user`.`user_id`=NEW.`user_id`;
        IF NEW.`user_id` != OLD.`user_id` THEN
          UPDATE `user`, (SELECT COUNT(*) AS `hidden_count` FROM `caches` WHERE `user_id`=OLD.`user_id` AND `status` IN (1, 2, 3)) AS `c` SET `user`.`hidden_count`=`c`.`hidden_count` WHERE `user`.`user_id`=OLD.`user_id`;
        END IF;
      END IF;
    END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cachesAfterDelete`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cachesAfterDelete` AFTER DELETE ON `ocpl`.`caches`
 FOR EACH ROW BEGIN
      DELETE FROM `cache_coordinates` WHERE `cache_id`=OLD.`cache_id`;
      DELETE FROM `cache_countries` WHERE `cache_id`=OLD.`cache_id`;
	  DELETE FROM `cache_npa_areas` WHERE `cache_id`=OLD.`cache_id`;
      UPDATE `user`, (SELECT COUNT(*) AS `hidden_count` FROM `caches` WHERE `user_id`=OLD.`user_id` AND `status` IN (1, 2, 3)) AS `c` SET `user`.`hidden_count`=`c`.`hidden_count` WHERE `user`.`user_id`=OLD.`user_id`;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `caches_attributes`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 09 Maj 2012, 00:56
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `caches_attributes` (
  `cache_id` int(11) NOT NULL,
  `attrib_id` int(11) NOT NULL,
  PRIMARY KEY (`cache_id`,`attrib_id`),
  KEY `attrib_id` (`attrib_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `caches_memory`
--

CREATE TABLE IF NOT EXISTS `caches_memory` (
  `cache_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `date_hidden` datetime DEFAULT NULL,
  `founds` int(11) DEFAULT NULL,
  `notfounds` int(11) DEFAULT NULL,
  `notes` int(11) DEFAULT NULL,
  `images` int(11) DEFAULT NULL,
  `last_found` datetime DEFAULT NULL,
  `desc_languages` varchar(60) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `difficulty` int(11) DEFAULT NULL,
  `terrain` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `watcher` int(11) DEFAULT NULL,
  `logpw` varchar(20) DEFAULT NULL,
  `picturescount` int(11) NOT NULL DEFAULT '0',
  `mp3count` int(11) NOT NULL DEFAULT '0',
  `search_time` double DEFAULT NULL,
  `way_length` double DEFAULT NULL,
  `wp_gc` varchar(7) NOT NULL,
  `wp_nc` varchar(6) NOT NULL,
  `wp_oc` varchar(6) DEFAULT NULL,
  `default_desclang` char(2) NOT NULL,
  `date_activate` datetime DEFAULT NULL,
  `topratings` int(11) NOT NULL DEFAULT '0',
  `ignorer_count` int(11) DEFAULT NULL,
  `node` tinyint(4) NOT NULL DEFAULT '0',
  `votes` int(11) NOT NULL DEFAULT '0',
  `score` float(2,1) NOT NULL DEFAULT '0.0',
  `need_npa_recalc` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cache_id`),
  UNIQUE KEY `wp_oc` (`wp_oc`),
  KEY `longitude` (`longitude`,`latitude`),
  KEY `date_created` (`date_created`),
  KEY `latitude` (`latitude`),
  KEY `country` (`country`),
  KEY `status` (`status`,`date_activate`),
  KEY `last_modified` (`last_modified`),
  KEY `score` (`score`),
  KEY `type` (`type`),
  KEY `size` (`size`),
  KEY `difficulty` (`difficulty`),
  KEY `terrain` (`terrain`),
  KEY `name` (`name`),
  KEY `votes` (`votes`),
  KEY `picturescount` (`picturescount`),
  KEY `user_id` (`user_id`),
  KEY `need_npa_recalc` (`need_npa_recalc`),
  KEY `latitude_2` (`latitude`) USING BTREE,
  KEY `longitude_2` (`longitude`) USING BTREE,
  KEY `score_2` (`score`) USING BTREE,
  KEY `votes_2` (`votes`) USING BTREE
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_arch`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 09 Maj 2012, 04:30
--

CREATE TABLE IF NOT EXISTS `cache_arch` (
  `cache_id` int(11) NOT NULL,
  `step` int(11) NOT NULL,
  PRIMARY KEY (`cache_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin2;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_attrib`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 24 Lut 2011, 12:25
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:25
--

CREATE TABLE IF NOT EXISTS `cache_attrib` (
  `id` int(11) NOT NULL DEFAULT '0',
  `language` char(2) NOT NULL,
  `text_short` varchar(20) NOT NULL,
  `text_long` varchar(60) NOT NULL,
  `icon_large` varchar(60) NOT NULL,
  `icon_no` varchar(60) NOT NULL,
  `icon_undef` varchar(60) NOT NULL,
  `category` tinyint(2) NOT NULL DEFAULT '0',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`language`,`id`),
  KEY `category` (`category`,`id`),
  KEY `default` (`default`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_coordinates`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 08 Maj 2012, 23:16
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:25
--

CREATE TABLE IF NOT EXISTS `cache_coordinates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL,
  `date_modified` datetime NOT NULL,
  `longitude` double NOT NULL,
  `latitude` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`cache_id`,`date_modified`),
  KEY `longitude` (`longitude`),
  KEY `latitude` (`latitude`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_countries`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 08 Maj 2012, 22:51
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:25
--

CREATE TABLE IF NOT EXISTS `cache_countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL,
  `date_modified` datetime NOT NULL,
  `country` char(2) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`cache_id`,`date_modified`),
  KEY `country` (`country`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_desc`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 09 Maj 2012, 06:36
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:25
--

CREATE TABLE IF NOT EXISTS `cache_desc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) DEFAULT NULL,
  `language` char(2) DEFAULT NULL,
  `desc` mediumtext,
  `desc_html` tinyint(1) NOT NULL DEFAULT '0',
  `desc_htmledit` tinyint(1) NOT NULL DEFAULT '0',
  `hint` mediumtext,
  `short_desc` varchar(120) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `last_modified` datetime DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `node` tinyint(4) NOT NULL DEFAULT '0',
  `rr_comment` mediumtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cache_id` (`cache_id`,`language`),
  KEY `last_modified` (`last_modified`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

--
-- Triggers `cache_desc`
--
DROP TRIGGER `ocpl`.`cacheDescBeforeInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheDescBeforeInsert` BEFORE INSERT ON `ocpl`.`cache_desc`
 FOR EACH ROW BEGIN
      SET NEW.`date_created`=NOW();
    END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cacheDescAfterInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheDescAfterInsert` AFTER INSERT ON `ocpl`.`cache_desc`
 FOR EACH ROW BEGIN
      UPDATE `caches`, (SELECT `cache_id`, GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `lang` FROM `cache_desc` GROUP BY `cache_id`) AS `tbl2` SET `caches`.`desc_languages`=`tbl2`.`lang` WHERE `caches`.`cache_id`=`tbl2`.`cache_id` AND `tbl2`.`cache_id`=NEW.`cache_id`;
    END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cacheDescAfterUpdate`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheDescAfterUpdate` AFTER UPDATE ON `ocpl`.`cache_desc`
 FOR EACH ROW BEGIN
      IF OLD.`cache_id` != NEW.`cache_id` OR OLD.`language` != NEW.`language` THEN
        UPDATE `caches`, (SELECT `cache_id`, GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `lang` FROM `cache_desc` GROUP BY `cache_id`) AS `tbl2` SET `caches`.`desc_languages`=`tbl2`.`lang` WHERE `caches`.`cache_id`=`tbl2`.`cache_id` AND `tbl2`.`cache_id`=NEW.`cache_id`;
        IF OLD.`cache_id` != NEW.`cache_id` THEN
          UPDATE `caches`, (SELECT `cache_id`, GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `lang` FROM `cache_desc` GROUP BY `cache_id`) AS `tbl2` SET `caches`.`desc_languages`=`tbl2`.`lang` WHERE `caches`.`cache_id`=`tbl2`.`cache_id` AND `tbl2`.`cache_id`=OLD.`cache_id`;
        END IF;
      END IF;
    END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cacheDescAfterDelete`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheDescAfterDelete` AFTER DELETE ON `ocpl`.`cache_desc`
 FOR EACH ROW BEGIN
      UPDATE `caches`, (SELECT `cache_id`, GROUP_CONCAT(DISTINCT `language` ORDER BY `language` SEPARATOR ',') AS `lang` FROM `cache_desc` GROUP BY `cache_id`) AS `tbl2` SET `caches`.`desc_languages`=`tbl2`.`lang` WHERE `caches`.`cache_id`=`tbl2`.`cache_id` AND `tbl2`.`cache_id`=OLD.`cache_id`; 
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_ignore`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 08 Maj 2012, 23:38
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:25
--

CREATE TABLE IF NOT EXISTS `cache_ignore` (
  `cache_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_loc`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `cache_loc` (
  `cache_id` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `lang` varchar(2) COLLATE utf8_polish_ci NOT NULL,
  `country` varchar(120) COLLATE utf8_polish_ci DEFAULT NULL,
  `adm1` varchar(120) COLLATE utf8_polish_ci DEFAULT NULL,
  `adm2` varchar(120) COLLATE utf8_polish_ci DEFAULT NULL,
  PRIMARY KEY (`cache_id`,`lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_location`
--
-- Utworzenie: 24 Lut 2011, 12:25
-- Ostatnia aktualizacja: 09 Maj 2012, 00:56
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:25
--

CREATE TABLE IF NOT EXISTS `cache_location` (
  `cache_id` int(10) unsigned NOT NULL,
  `last_modified` datetime NOT NULL COMMENT 'via Trigger (cache_location)',
  `adm1` varchar(120) DEFAULT NULL,
  `adm2` varchar(120) DEFAULT NULL,
  `adm3` varchar(120) DEFAULT NULL,
  `adm4` varchar(120) DEFAULT NULL,
  `code1` varchar(2) DEFAULT NULL,
  `code2` varchar(3) DEFAULT NULL,
  `code3` varchar(4) DEFAULT NULL,
  `code4` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`cache_id`),
  KEY `code1` (`code1`,`code2`,`code3`,`code4`),
  KEY `adm1` (`adm1`,`adm2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='via cronjob';

--
-- Triggers `cache_location`
--
DROP TRIGGER `ocpl`.`cacheLocationBeforeInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheLocationBeforeInsert` BEFORE INSERT ON `ocpl`.`cache_location`
 FOR EACH ROW BEGIN
      SET NEW.`last_modified`=NOW();
    END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cacheLocationBeforeUpdate`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheLocationBeforeUpdate` BEFORE UPDATE ON `ocpl`.`cache_location`
 FOR EACH ROW BEGIN
      SET NEW.`last_modified`=NOW();
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_logs`
--
-- Utworzenie: 10 Kwi 2012, 18:14
--

CREATE TABLE IF NOT EXISTS `cache_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `text` mediumtext,
  `text_html` tinyint(1) NOT NULL DEFAULT '0',
  `text_htmledit` tinyint(1) NOT NULL DEFAULT '0',
  `last_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uuid` varchar(36) DEFAULT NULL,
  `picturescount` int(11) NOT NULL DEFAULT '0',
  `mp3count` int(11) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner_notified` int(1) NOT NULL DEFAULT '0',
  `node` tinyint(4) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  `encrypt` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`),
  KEY `date` (`date`),
  KEY `owner_notified` (`owner_notified`),
  KEY `last_modified` (`last_modified`),
  KEY `type` (`type`),
  KEY `date_created` (`date_created`),
  KEY `deleted` (`deleted`),
  KEY `cache_id_user_id` (`cache_id`,`user_id`),
  KEY `uuid` (`uuid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_maps`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 24 Lut 2011, 12:26
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `cache_maps` (
  `cache_id` int(11) NOT NULL DEFAULT '0',
  `last_refresh` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`cache_id`),
  KEY `last_refresh` (`last_refresh`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_moved`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 24 Lut 2011, 12:26
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `cache_moved` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `log_id` int(11) DEFAULT NULL,
  `date` datetime NOT NULL,
  `longitude` double NOT NULL,
  `latitude` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`cache_id`,`date`),
  KEY `longitude` (`longitude`),
  KEY `latitude` (`latitude`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_notes`
--
-- Utworzenie: 22 Cze 2011, 12:04
-- Ostatnia aktualizacja: 09 Maj 2012, 03:13
-- Ostatnie sprawdzenie: 22 Cze 2011, 12:04
--

CREATE TABLE IF NOT EXISTS `cache_notes` (
  `note_id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `desc_html` tinyint(1) NOT NULL DEFAULT '1',
  `desc` text NOT NULL,
  PRIMARY KEY (`note_id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`),
  KEY `date` (`date`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='cache notes';

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_npa_areas`
--
-- Utworzenie: 18 Lut 2012, 10:45
-- Ostatnia aktualizacja: 08 Maj 2012, 23:00
--

CREATE TABLE IF NOT EXISTS `cache_npa_areas` (
  `cache_id` int(10) unsigned NOT NULL,
  `npa_id` int(10) unsigned NOT NULL,
  `parki_id` int(10) unsigned NOT NULL,
  `calculated` tinyint(1) NOT NULL,
  PRIMARY KEY (`cache_id`,`npa_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_rating`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 09 Maj 2012, 02:54
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `cache_rating` (
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`cache_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Triggers `cache_rating`
--
DROP TRIGGER `ocpl`.`cacheRatingAfterInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheRatingAfterInsert` AFTER INSERT ON `ocpl`.`cache_rating`
 FOR EACH ROW BEGIN  
      UPDATE `caches` SET `topratings`=(SELECT COUNT(*) FROM `cache_rating` WHERE `cache_rating`.`cache_id`=NEW.`cache_id`) WHERE `cache_id`=NEW.`cache_id`;
    END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cacheRatingAfterUpdate`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheRatingAfterUpdate` AFTER UPDATE ON `ocpl`.`cache_rating`
 FOR EACH ROW BEGIN  
      IF OLD.`cache_id`!=NEW.`cache_id` THEN
        UPDATE `caches` SET `topratings`=(SELECT COUNT(*) FROM `cache_rating` WHERE `cache_rating`.`cache_id`=OLD.`cache_id`) WHERE `cache_id`=OLD.`cache_id`;
        UPDATE `caches` SET `topratings`=(SELECT COUNT(*) FROM `cache_rating` WHERE `cache_rating`.`cache_id`=NEW.`cache_id`) WHERE `cache_id`=NEW.`cache_id`;
      END IF;
    END
//
DELIMITER ;
DROP TRIGGER `ocpl`.`cacheRatingAfterDelete`;
DELIMITER //
CREATE TRIGGER `ocpl`.`cacheRatingAfterDelete` AFTER DELETE ON `ocpl`.`cache_rating`
 FOR EACH ROW BEGIN
      UPDATE `caches` SET `topratings`=(SELECT COUNT(*) FROM `cache_rating` WHERE `cache_rating`.`cache_id`=OLD.`cache_id`) WHERE `cache_id`=OLD.`cache_id`;
    END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_size`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 07 Lip 2011, 12:30
--

CREATE TABLE IF NOT EXISTS `cache_size` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_status`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 19 Paź 2011, 12:41
--

CREATE TABLE IF NOT EXISTS `cache_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_type`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `cache_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) NOT NULL DEFAULT '100',
  `short` varchar(10) NOT NULL,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  `icon_large` varchar(60) NOT NULL,
  `icon_small` varchar(60) NOT NULL,
  `color` varchar(7) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_visits`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 09 Maj 2012, 07:21
--

CREATE TABLE IF NOT EXISTS `cache_visits` (
  `cache_id` int(11) NOT NULL DEFAULT '0',
  `user_id_ip` varchar(15) NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `last_visited` datetime DEFAULT NULL,
  PRIMARY KEY (`cache_id`,`user_id_ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `cache_watches`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 09 Maj 2012, 07:21
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `cache_watches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `last_executed` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`),
  KEY `cache_id_user_id` (`cache_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `chowner`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 08 Maj 2012, 14:40
--

CREATE TABLE IF NOT EXISTS `chowner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `countries`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 01 Kwi 2012, 08:38
--

CREATE TABLE IF NOT EXISTS `countries` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `pl` varchar(128) NOT NULL,
  `en` varchar(128) NOT NULL,
  `short` char(2) NOT NULL,
  `list_default_pl` int(1) NOT NULL DEFAULT '0',
  `sort_pl` varchar(128) NOT NULL,
  `list_default_en` int(1) NOT NULL DEFAULT '0',
  `sort_en` varchar(128) NOT NULL,
  PRIMARY KEY (`country_id`),
  UNIQUE KEY `short` (`short`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `email_schemas`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `email_schemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `shortdesc` varchar(100) NOT NULL,
  `text` varchar(10000) NOT NULL,
  `receiver` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `email_user`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 09 Maj 2012, 01:00
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `email_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(20) NOT NULL,
  `date_generated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `from_user_id` int(11) NOT NULL DEFAULT '0',
  `from_email` varchar(60) NOT NULL,
  `to_user_id` int(11) NOT NULL DEFAULT '0',
  `to_email` varchar(60) NOT NULL,
  `mail_subject` varchar(255) NOT NULL,
  `mail_text` text NOT NULL,
  `send_emailaddress` int(1) NOT NULL DEFAULT '0',
  `date_sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `date_sent` (`date_sent`),
  KEY `from_user_id` (`from_user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `foreign_caches`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `foreign_caches` (
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(90) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `date_hidden` datetime DEFAULT NULL,
  `founds` int(11) DEFAULT NULL,
  `notfounds` int(11) DEFAULT NULL,
  `notes` int(11) DEFAULT NULL,
  `images` int(11) DEFAULT NULL,
  `last_found` datetime DEFAULT NULL,
  `desc_languages` varchar(60) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `difficulty` int(11) DEFAULT NULL,
  `terrain` int(11) DEFAULT NULL,
  `uuid` varchar(36) DEFAULT NULL,
  `watcher` int(11) DEFAULT NULL,
  `logpw` varchar(20) DEFAULT NULL,
  `picturescount` int(11) NOT NULL DEFAULT '0',
  `search_time` double DEFAULT NULL,
  `way_length` double DEFAULT NULL,
  `wp_gc` varchar(7) NOT NULL,
  `wp_nc` varchar(6) NOT NULL,
  `wp_oc` varchar(6) DEFAULT NULL,
  `default_desclang` char(2) NOT NULL,
  `date_activate` datetime DEFAULT NULL,
  `topratings` int(11) NOT NULL DEFAULT '0',
  `ignorer_count` int(11) DEFAULT NULL,
  `node` tinyint(4) NOT NULL DEFAULT '0',
  `votes` int(11) NOT NULL DEFAULT '0',
  `score` float(2,1) NOT NULL DEFAULT '0.0',
  PRIMARY KEY (`cache_id`,`node`),
  UNIQUE KEY `wp_oc` (`wp_oc`),
  KEY `longitude` (`longitude`,`latitude`),
  KEY `date_created` (`date_created`),
  KEY `latitude` (`latitude`),
  KEY `country` (`country`),
  KEY `status` (`status`,`date_activate`),
  KEY `last_modified` (`last_modified`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_areas`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_areas` (
  `loc_id` int(11) NOT NULL DEFAULT '0',
  `area_id` int(11) NOT NULL DEFAULT '0',
  `polygon_id` int(11) DEFAULT NULL,
  `pol_seq_no` int(11) NOT NULL DEFAULT '0',
  `exclude_area` smallint(1) NOT NULL DEFAULT '0',
  `area_type` int(11) NOT NULL DEFAULT '0',
  `area_subtype` int(11) DEFAULT NULL,
  `coord_type` int(11) NOT NULL DEFAULT '0',
  `coord_subtype` int(11) DEFAULT NULL,
  `resolution` int(11) NOT NULL DEFAULT '0',
  `valid_since` date DEFAULT NULL,
  `date_type_since` int(11) DEFAULT NULL,
  `valid_until` date NOT NULL DEFAULT '0000-00-00',
  `date_type_until` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `loc_id` (`loc_id`,`area_id`),
  KEY `areas_loc_id_idx` (`loc_id`),
  KEY `areas_area_id_idx` (`area_id`),
  KEY `areas_pol_id_idx` (`polygon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_changelog`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_changelog` (
  `id` int(11) NOT NULL DEFAULT '0',
  `datum` date NOT NULL DEFAULT '0000-00-00',
  `beschreibung` text NOT NULL,
  `autor` varchar(50) NOT NULL DEFAULT '',
  `version` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_coordinates`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_coordinates` (
  `loc_id` int(11) NOT NULL DEFAULT '0',
  `lon` double DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `coord_type` int(11) NOT NULL DEFAULT '0',
  `coord_subtype` int(11) DEFAULT NULL,
  `valid_since` date DEFAULT NULL,
  `date_type_since` int(11) DEFAULT NULL,
  `valid_until` date NOT NULL DEFAULT '0000-00-00',
  `date_type_until` int(11) NOT NULL DEFAULT '0',
  KEY `coord_loc_id_idx` (`loc_id`),
  KEY `coord_lon_idx` (`lon`),
  KEY `coord_lat_idx` (`lat`),
  KEY `coord_type_idx` (`coord_type`),
  KEY `coord_stype_idx` (`coord_subtype`),
  KEY `coord_since_idx` (`valid_since`),
  KEY `coord_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_floatdata`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_floatdata` (
  `loc_id` int(11) NOT NULL DEFAULT '0',
  `float_val` double NOT NULL DEFAULT '0',
  `float_type` int(11) NOT NULL DEFAULT '0',
  `float_subtype` int(11) DEFAULT NULL,
  `valid_since` date DEFAULT NULL,
  `date_type_since` int(11) DEFAULT NULL,
  `valid_until` date NOT NULL DEFAULT '0000-00-00',
  `date_type_until` int(11) NOT NULL DEFAULT '0',
  KEY `float_lid_idx` (`loc_id`),
  KEY `float_val_idx` (`float_val`),
  KEY `float_type_idx` (`float_type`),
  KEY `float_stype_idx` (`float_subtype`),
  KEY `float_since_idx` (`valid_since`),
  KEY `float_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_hierarchies`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_hierarchies` (
  `loc_id` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL DEFAULT '0',
  `id_lvl1` int(11) NOT NULL DEFAULT '0',
  `id_lvl2` int(11) DEFAULT NULL,
  `id_lvl3` int(11) DEFAULT NULL,
  `id_lvl4` int(11) DEFAULT NULL,
  `id_lvl5` int(11) DEFAULT NULL,
  `id_lvl6` int(11) DEFAULT NULL,
  `id_lvl7` int(11) DEFAULT NULL,
  `id_lvl8` int(11) DEFAULT NULL,
  `id_lvl9` int(11) DEFAULT NULL,
  `valid_since` date DEFAULT NULL,
  `date_type_since` int(11) DEFAULT NULL,
  `valid_until` date NOT NULL DEFAULT '0000-00-00',
  `date_type_until` int(11) NOT NULL DEFAULT '0',
  KEY `hierarchy_loc_id_idx` (`loc_id`),
  KEY `hierarchy_level_idx` (`level`),
  KEY `hierarchy_lvl1_idx` (`id_lvl1`),
  KEY `hierarchy_lvl2_idx` (`id_lvl2`),
  KEY `hierarchy_lvl3_idx` (`id_lvl3`),
  KEY `hierarchy_lvl4_idx` (`id_lvl4`),
  KEY `hierarchy_lvl5_idx` (`id_lvl5`),
  KEY `hierarchy_lvl6_idx` (`id_lvl6`),
  KEY `hierarchy_lvl7_idx` (`id_lvl7`),
  KEY `hierarchy_lvl8_idx` (`id_lvl8`),
  KEY `hierarchy_lvl9_idx` (`id_lvl9`),
  KEY `hierarchy_since_idx` (`valid_since`),
  KEY `hierarchy_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_intdata`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_intdata` (
  `loc_id` int(11) NOT NULL DEFAULT '0',
  `int_val` bigint(20) NOT NULL DEFAULT '0',
  `int_type` int(11) NOT NULL DEFAULT '0',
  `int_subtype` int(11) DEFAULT NULL,
  `valid_since` date DEFAULT NULL,
  `date_type_since` int(11) DEFAULT NULL,
  `valid_until` date NOT NULL DEFAULT '0000-00-00',
  `date_type_until` int(11) NOT NULL DEFAULT '0',
  KEY `int_lid_idx` (`loc_id`),
  KEY `int_val_idx` (`int_val`),
  KEY `int_type_idx` (`int_type`),
  KEY `int_stype_idx` (`int_subtype`),
  KEY `int_since_idx` (`valid_since`),
  KEY `int_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_locations`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_locations` (
  `loc_id` int(11) NOT NULL DEFAULT '0',
  `loc_type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`loc_id`),
  KEY `loc_type_idx` (`loc_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_polygons`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_polygons` (
  `polygon_id` int(11) NOT NULL DEFAULT '0',
  `seq_no` int(11) NOT NULL DEFAULT '0',
  `lon` double NOT NULL DEFAULT '0',
  `lat` double NOT NULL DEFAULT '0',
  UNIQUE KEY `polygon_id` (`polygon_id`,`seq_no`),
  KEY `polygons_pid_idx` (`polygon_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_search`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 24 Lut 2011, 12:26
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `geodb_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `loc_id` int(11) NOT NULL DEFAULT '0',
  `sort` varchar(255) NOT NULL,
  `simple` varchar(255) NOT NULL,
  `simplehash` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sort` (`sort`),
  KEY `simple` (`simple`),
  KEY `simplehash` (`simplehash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_textdata`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_textdata` (
  `loc_id` int(11) NOT NULL DEFAULT '0',
  `text_val` varchar(255) NOT NULL DEFAULT '',
  `text_type` int(11) NOT NULL DEFAULT '0',
  `text_locale` varchar(5) DEFAULT NULL,
  `is_native_lang` smallint(1) DEFAULT NULL,
  `is_default_name` smallint(1) DEFAULT NULL,
  `valid_since` date DEFAULT NULL,
  `date_type_since` int(11) DEFAULT NULL,
  `valid_until` date NOT NULL DEFAULT '0000-00-00',
  `date_type_until` int(11) NOT NULL DEFAULT '0',
  KEY `text_lid_idx` (`loc_id`),
  KEY `text_val_idx` (`text_val`),
  KEY `text_type_idx` (`text_type`),
  KEY `text_locale_idx` (`text_locale`),
  KEY `text_native_idx` (`is_native_lang`),
  KEY `text_default_idx` (`is_default_name`),
  KEY `text_since_idx` (`valid_since`),
  KEY `text_until_idx` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `geodb_type_names`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `geodb_type_names` (
  `type_id` int(11) NOT NULL DEFAULT '0',
  `type_locale` varchar(5) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `type_id` (`type_id`,`type_locale`),
  KEY `tid_tnames_idx` (`type_id`),
  KEY `locale_tnames_idx` (`type_locale`),
  KEY `name_tnames_idx` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_item`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `gk_item` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  `description` longtext NOT NULL,
  `userid` int(11) NOT NULL,
  `datecreated` datetime NOT NULL,
  `datemodified` datetime NOT NULL,
  `distancetravelled` float NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `typeid` int(11) NOT NULL,
  `stateid` tinyint(4) NOT NULL,
  `missing` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `stateid` (`stateid`),
  KEY `typeid` (`typeid`),
  KEY `id_stateid_typeid` (`id`,`stateid`,`typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_item_type`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 26 Sie 2011, 08:30
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `gk_item_type` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_item_waypoint`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `gk_item_waypoint` (
  `id` int(11) NOT NULL,
  `wp` varchar(10) NOT NULL,
  PRIMARY KEY (`id`,`wp`),
  KEY `wp` (`wp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_move`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 24 Lut 2011, 12:26
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `gk_move` (
  `id` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `datemoved` datetime NOT NULL,
  `datelogged` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `comment` longtext NOT NULL,
  `logtypeid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `itemid` (`itemid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_move_type`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 24 Lut 2011, 12:26
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `gk_move_type` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_move_waypoint`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 24 Lut 2011, 12:26
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `gk_move_waypoint` (
  `id` int(11) NOT NULL,
  `wp` varchar(10) NOT NULL,
  PRIMARY KEY (`id`,`wp`),
  KEY `wp` (`wp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gk_user`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 25 Sie 2011, 23:30
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `gk_user` (
  `id` int(11) NOT NULL,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gns_locations`
--
-- Utworzenie: 12 Lip 2011, 06:50
-- Ostatnia aktualizacja: 12 Lip 2011, 06:50
--

CREATE TABLE IF NOT EXISTS `gns_locations` (
  `rc` tinyint(4) NOT NULL DEFAULT '0',
  `ufi` int(11) NOT NULL DEFAULT '0',
  `uni` int(11) NOT NULL DEFAULT '0',
  `lat` double NOT NULL DEFAULT '0',
  `lon` double NOT NULL DEFAULT '0',
  `dms_lat` int(11) NOT NULL DEFAULT '0',
  `dms_lon` int(11) NOT NULL DEFAULT '0',
  `utm` varchar(4) NOT NULL,
  `jog` varchar(7) NOT NULL,
  `fc` char(1) NOT NULL,
  `dsg` varchar(5) NOT NULL,
  `pc` tinyint(4) NOT NULL DEFAULT '0',
  `cc1` char(2) NOT NULL,
  `adm1` char(2) NOT NULL,
  `adm2` varchar(200) NOT NULL,
  `dim` int(11) NOT NULL DEFAULT '0',
  `cc2` char(2) NOT NULL,
  `nt` char(1) NOT NULL,
  `lc` char(2) NOT NULL,
  `SHORT_FORM` varchar(128) NOT NULL,
  `GENERIC` varchar(128) NOT NULL,
  `SORT_NAME` varchar(200) NOT NULL,
  `FULL_NAME` varchar(200) NOT NULL,
  `FULL_NAME_ND` varchar(200) NOT NULL,
  `MOD_DATE` date NOT NULL DEFAULT '0000-00-00',
  `admtxt1` varchar(120) NOT NULL,
  `admtxt3` varchar(120) NOT NULL,
  `admtxt4` varchar(120) NOT NULL,
  `admtxt2` varchar(120) NOT NULL,
  PRIMARY KEY (`uni`),
  KEY `rc` (`rc`,`fc`,`dsg`,`cc1`),
  KEY `ufi` (`ufi`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `gns_search`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 12 Lip 2011, 06:53
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `gns_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uni_id` int(11) NOT NULL DEFAULT '0',
  `sort` varchar(255) NOT NULL,
  `simple` varchar(255) NOT NULL,
  `simplehash` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `simplehash` (`simplehash`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `import_caches_date`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 09 Maj 2012, 06:37
--

CREATE TABLE IF NOT EXISTS `import_caches_date` (
  `node_id` int(11) NOT NULL,
  `updated` int(11) NOT NULL,
  PRIMARY KEY (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `languages`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short` char(2) NOT NULL,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  `list_default_pl` int(1) NOT NULL DEFAULT '0',
  `list_default_en` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `short` (`short`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `logentries`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 09 Maj 2012, 07:01
--

CREATE TABLE IF NOT EXISTS `logentries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(30) NOT NULL,
  `eventid` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `objectid1` int(11) NOT NULL DEFAULT '0',
  `objectid2` int(11) NOT NULL DEFAULT '0',
  `logtext` mediumtext NOT NULL,
  `details` blob NOT NULL,
  `logtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `logentries_types`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `logentries_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(30) NOT NULL,
  `eventname` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `logins`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `remote_addr` varchar(15) NOT NULL,
  `success` int(1) NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `log_types`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 12 Wrz 2011, 14:34
--

CREATE TABLE IF NOT EXISTS `log_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_status` int(1) NOT NULL DEFAULT '0',
  `permission` char(1) NOT NULL,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  `icon_small` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `log_types_text`
--
-- Utworzenie: 24 Lut 2011, 12:26
-- Ostatnia aktualizacja: 06 Cze 2011, 06:34
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:26
--

CREATE TABLE IF NOT EXISTS `log_types_text` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_types_id` int(11) NOT NULL DEFAULT '0',
  `lang` char(2) NOT NULL,
  `text_combo` varchar(255) NOT NULL,
  `text_listing` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lang` (`lang`,`log_types_id`),
  KEY `log_types_id` (`log_types_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `map_settings`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 09 Maj 2012, 03:24
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `map_settings` (
  `user_id` int(11) NOT NULL,
  `unknown` int(1) DEFAULT '1',
  `traditional` int(1) DEFAULT '1',
  `multicache` int(1) DEFAULT '1',
  `virtual` int(1) DEFAULT '1',
  `webcam` int(1) DEFAULT '1',
  `event` int(1) DEFAULT '1',
  `quiz` int(1) DEFAULT '1',
  `math` int(1) DEFAULT '1',
  `mobile` int(1) DEFAULT '1',
  `drivein` int(1) DEFAULT '1',
  `podcast` int(1) DEFAULT '1',
  `owncache` int(1) DEFAULT '1',
  `ignored` int(1) DEFAULT '0',
  `own` int(1) DEFAULT '1',
  `found` int(1) DEFAULT '1',
  `notyetfound` int(1) DEFAULT '1',
  `geokret` int(1) DEFAULT '1',
  `showsign` int(1) DEFAULT '0',
  `showwp` int(1) NOT NULL DEFAULT '0',
  `active` int(1) DEFAULT '1',
  `notactive` int(1) DEFAULT '0',
  `maptype` int(1) DEFAULT '3',
  `cachelimit` int(1) DEFAULT '4',
  `cachesort` int(1) DEFAULT '1',
  `archived` int(1) DEFAULT '0',
  `be_ftf` int(1) DEFAULT '0',
  `de` int(1) DEFAULT '1',
  `pl` int(1) DEFAULT '1',
  `no` int(1) NOT NULL DEFAULT '0',
  `se` int(1) NOT NULL DEFAULT '0',
  `min_score` int(1) NOT NULL DEFAULT '-3',
  `max_score` int(1) NOT NULL DEFAULT '3',
  `noscore` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`),
  KEY `min_score` (`min_score`),
  KEY `max_score` (`max_score`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `map_settings_v2`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 09 Maj 2012, 05:57
--

CREATE TABLE IF NOT EXISTS `map_settings_v2` (
  `user_id` int(11) NOT NULL,
  `unknown` int(1) DEFAULT '1',
  `traditional` int(1) DEFAULT '1',
  `multicache` int(1) DEFAULT '1',
  `virtual` int(1) DEFAULT '1',
  `webcam` int(1) DEFAULT '1',
  `event` int(1) DEFAULT '1',
  `quiz` int(1) DEFAULT '1',
  `math` int(1) DEFAULT '1',
  `mobile` int(1) DEFAULT '1',
  `drivein` int(1) DEFAULT '1',
  `ignored` int(1) DEFAULT '0',
  `own` int(1) DEFAULT '1',
  `found` int(1) DEFAULT '1',
  `notyetfound` int(1) DEFAULT '1',
  `geokret` int(1) DEFAULT '1',
  `showsign` int(1) DEFAULT '0',
  `active` int(1) DEFAULT '0',
  `notactive` int(1) DEFAULT '1',
  `maptype` int(1) DEFAULT '3',
  `cachelimit` int(1) DEFAULT '4',
  `cachesort` int(1) DEFAULT '1',
  `archived` int(1) DEFAULT '0',
  `be_ftf` int(1) DEFAULT '0',
  `de` int(1) DEFAULT '1',
  `pl` int(1) DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `mp3`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 03 Maj 2012, 13:45
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `mp3` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `url` varchar(255) NOT NULL,
  `last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `title` varchar(250) DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_url_check` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `object_id` int(11) NOT NULL DEFAULT '0',
  `object_type` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `local` int(1) NOT NULL DEFAULT '1',
  `unknown_format` int(1) NOT NULL DEFAULT '0',
  `display` int(1) NOT NULL DEFAULT '1',
  `node` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `last_modified` (`last_modified`),
  KEY `url` (`url`),
  KEY `title` (`title`),
  KEY `object_id` (`object_id`),
  KEY `uuid` (`uuid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `news`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 20 Kwi 2012, 09:16
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_posted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `content` text NOT NULL,
  `topic` int(11) NOT NULL DEFAULT '0',
  `display` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `topic` (`topic`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `news_topics`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `news_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `nodes`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `url` varchar(260) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `notify_waiting`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 08 Maj 2012, 23:45
--

CREATE TABLE IF NOT EXISTS `notify_waiting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cache_user` (`cache_id`,`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `npa_areas`
--
-- Utworzenie: 21 Mar 2012, 19:38
-- Ostatnia aktualizacja: 21 Mar 2012, 19:43
-- Ostatnie sprawdzenie: 21 Mar 2012, 19:38
--

CREATE TABLE IF NOT EXISTS `npa_areas` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `linkid` int(4) DEFAULT NULL,
  `sitename` varchar(255) NOT NULL,
  `sitecode` varchar(255) NOT NULL,
  `sitetype` char(1) NOT NULL,
  `shape` linestring NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shape` (`sitecode`(32))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `nuts_codes`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `nuts_codes` (
  `code` varchar(10) NOT NULL,
  `name` varchar(120) NOT NULL,
  PRIMARY KEY (`code`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `nuts_layer`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `nuts_layer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` tinyint(1) NOT NULL,
  `code` varchar(5) NOT NULL,
  `shape` linestring NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `level` (`level`),
  SPATIAL KEY `shape` (`shape`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `object_types`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `object_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_authorizations`
--
-- Utworzenie: 27 Sty 2012, 14:26
-- Ostatnia aktualizacja: 08 Maj 2012, 20:02
--

CREATE TABLE IF NOT EXISTS `okapi_authorizations` (
  `consumer_key` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL,
  `last_access_token` datetime DEFAULT NULL,
  PRIMARY KEY (`consumer_key`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_cache`
--
-- Utworzenie: 13 Mar 2012, 03:55
-- Ostatnia aktualizacja: 09 Maj 2012, 07:20
--

CREATE TABLE IF NOT EXISTS `okapi_cache` (
  `key` varchar(64) NOT NULL,
  `value` mediumblob,
  `expires` datetime DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_cache_logs`
--
-- Utworzenie: 27 Sty 2012, 14:26
-- Ostatnia aktualizacja: 08 Maj 2012, 21:22
-- Ostatnie sprawdzenie: 27 Sty 2012, 14:26
--

CREATE TABLE IF NOT EXISTS `okapi_cache_logs` (
  `log_id` int(11) NOT NULL,
  `consumer_key` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `by_consumer` (`consumer_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_clog`
--
-- Utworzenie: 13 Mar 2012, 03:55
-- Ostatnia aktualizacja: 09 Maj 2012, 07:00
--

CREATE TABLE IF NOT EXISTS `okapi_clog` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `data` mediumblob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_consumers`
--
-- Utworzenie: 27 Sty 2012, 14:26
-- Ostatnia aktualizacja: 07 Maj 2012, 13:56
--

CREATE TABLE IF NOT EXISTS `okapi_consumers` (
  `key` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(100) NOT NULL,
  `secret` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `url` varchar(250) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_nonces`
--

CREATE TABLE IF NOT EXISTS `okapi_nonces` (
  `consumer_key` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `key` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `timestamp` int(10) NOT NULL,
  PRIMARY KEY (`consumer_key`,`key`,`timestamp`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_stats_hourly`
--
-- Utworzenie: 07 Lut 2012, 10:38
-- Ostatnia aktualizacja: 09 Maj 2012, 07:20
--

CREATE TABLE IF NOT EXISTS `okapi_stats_hourly` (
  `consumer_key` varchar(32) NOT NULL,
  `user_id` int(10) NOT NULL,
  `period_start` datetime NOT NULL,
  `service_name` varchar(80) NOT NULL,
  `total_calls` int(10) NOT NULL,
  `http_calls` int(10) NOT NULL,
  `total_runtime` float NOT NULL DEFAULT '0',
  `http_runtime` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`consumer_key`,`user_id`,`period_start`,`service_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_stats_temp`
--

CREATE TABLE IF NOT EXISTS `okapi_stats_temp` (
  `datetime` datetime NOT NULL,
  `consumer_key` varchar(32) NOT NULL DEFAULT 'internal',
  `user_id` int(10) NOT NULL DEFAULT '-1',
  `service_name` varchar(80) NOT NULL,
  `calltype` enum('internal','http') NOT NULL,
  `runtime` float NOT NULL DEFAULT '0'
) ENGINE=MEMORY DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_tokens`
--
-- Utworzenie: 27 Sty 2012, 14:26
-- Ostatnia aktualizacja: 09 Maj 2012, 06:05
-- Ostatnie sprawdzenie: 27 Sty 2012, 14:26
--

CREATE TABLE IF NOT EXISTS `okapi_tokens` (
  `key` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `secret` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `token_type` enum('request','access') NOT NULL,
  `timestamp` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `consumer_key` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `verifier` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `callback` varchar(2083) DEFAULT NULL,
  PRIMARY KEY (`key`),
  KEY `by_consumer` (`consumer_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `okapi_vars`
--
-- Utworzenie: 27 Sty 2012, 14:26
-- Ostatnia aktualizacja: 09 Maj 2012, 07:20
--

CREATE TABLE IF NOT EXISTS `okapi_vars` (
  `var` varchar(32) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `value` text,
  PRIMARY KEY (`var`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `opensprawdzacz`
--
-- Utworzenie: 09 Maj 2012, 06:29
-- Ostatnia aktualizacja: 09 Maj 2012, 06:29
--

CREATE TABLE IF NOT EXISTS `opensprawdzacz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL,
  `proby` int(11) NOT NULL,
  `sukcesy` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `parkipl`
--
-- Utworzenie: 18 Lut 2012, 08:27
-- Ostatnia aktualizacja: 24 Mar 2012, 08:03
--

CREATE TABLE IF NOT EXISTS `parkipl` (
  `OGR_FID` int(11) NOT NULL AUTO_INCREMENT,
  `SHAPE` geometry NOT NULL,
  `id` double DEFAULT NULL,
  `name` varchar(80) CHARACTER SET utf8 COLLATE utf8_polish_ci DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL,
  `dispclass` double DEFAULT NULL,
  `xcoords` varchar(11) DEFAULT NULL,
  `ycoords` varchar(11) DEFAULT NULL,
  `link` varchar(240) CHARACTER SET utf8 COLLATE utf8_polish_ci NOT NULL DEFAULT 'www.parkinarodowe.edu.pl/pn/ 	',
  `logo` varchar(64) CHARACTER SET utf8 COLLATE utf8_polish_ci NOT NULL DEFAULT 'npa.png',
  UNIQUE KEY `OGR_FID` (`OGR_FID`),
  SPATIAL KEY `SHAPE` (`SHAPE`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `pictures`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 09 Maj 2012, 03:51
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(36) NOT NULL,
  `url` varchar(255) NOT NULL,
  `last_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `title` varchar(250) DEFAULT NULL,
  `description` text,
  `desc_html` int(11) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_url_check` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `object_id` int(11) NOT NULL DEFAULT '0',
  `object_type` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `thumb_url` varchar(255) NOT NULL,
  `thumb_last_generated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `spoiler` int(1) NOT NULL DEFAULT '0',
  `local` int(1) NOT NULL DEFAULT '1',
  `unknown_format` int(1) NOT NULL DEFAULT '0',
  `display` int(1) NOT NULL DEFAULT '1',
  `node` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `last_modified` (`last_modified`),
  KEY `url` (`url`),
  KEY `title` (`title`),
  KEY `object_id` (`object_id`),
  KEY `uuid` (`uuid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `queries`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 09 Maj 2012, 07:12
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(60) NOT NULL,
  `options` blob NOT NULL,
  `uuid` varchar(36) NOT NULL,
  `filters_count` int(11) NOT NULL DEFAULT '0',
  `last_queried` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UUID` (`uuid`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `removed_objects`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 08 Maj 2012, 23:50
--

CREATE TABLE IF NOT EXISTS `removed_objects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `localID` int(11) NOT NULL DEFAULT '0',
  `uuid` varchar(36) NOT NULL,
  `type` int(1) NOT NULL DEFAULT '0',
  `removed_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `node` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UUID` (`uuid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `reports`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 08 Maj 2012, 13:55
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `cache_id` int(11) NOT NULL,
  `type` tinyint(10) NOT NULL DEFAULT '4',
  `text` varchar(4096) NOT NULL,
  `note` text NOT NULL,
  `submit_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(3) NOT NULL DEFAULT '0',
  `changed_by` int(11) NOT NULL DEFAULT '0',
  `changed_date` timestamp NULL DEFAULT NULL,
  `responsible_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `routes`
--
-- Utworzenie: 18 Sie 2011, 01:17
--

CREATE TABLE IF NOT EXISTS `routes` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `radius` float DEFAULT NULL,
  `length` float DEFAULT NULL,
  `options` blob NOT NULL,
  PRIMARY KEY (`route_id`),
  KEY `name` (`name`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='routes name';

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `route_points`
--
-- Utworzenie: 21 Mar 2012, 20:23
--

CREATE TABLE IF NOT EXISTS `route_points` (
  `route_id` int(11) DEFAULT NULL,
  `point_nr` int(10) DEFAULT NULL,
  `lon` double DEFAULT NULL,
  `lat` double DEFAULT NULL,
  KEY `route_id` (`route_id`),
  KEY `lon` (`lon`,`lat`),
  KEY `lat` (`lat`),
  KEY `point_nr` (`point_nr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='route points';

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `rr_ocpl_candidates_2009`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `rr_ocpl_candidates_2009` (
  `candidate_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `city` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  PRIMARY KEY (`candidate_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `rr_ocpl_candidates_2010`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `rr_ocpl_candidates_2010` (
  `candidate_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `city` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  PRIMARY KEY (`candidate_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `rr_ocpl_candidates_2011`
--
-- Utworzenie: 16 Maj 2011, 23:22
-- Ostatnia aktualizacja: 31 Maj 2011, 20:58
--

CREATE TABLE IF NOT EXISTS `rr_ocpl_candidates_2011` (
  `candidate_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `city` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  PRIMARY KEY (`candidate_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `rr_ocpl_vote_2009`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `rr_ocpl_vote_2009` (
  `vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `rr_ocpl_vote_2010`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `rr_ocpl_vote_2010` (
  `vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `rr_ocpl_vote_2011`
--
-- Utworzenie: 16 Maj 2011, 23:22
-- Ostatnia aktualizacja: 14 Cze 2011, 23:48
--

CREATE TABLE IF NOT EXISTS `rr_ocpl_vote_2011` (
  `vote_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `candidate_id` int(11) NOT NULL,
  PRIMARY KEY (`vote_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `scores`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 09 Maj 2012, 06:57
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `scores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `score` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`cache_id`),
  KEY `user_id` (`user_id`),
  KEY `score` (`score`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_doubles`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `search_doubles` (
  `hash` int(10) unsigned NOT NULL,
  `word` varchar(30) NOT NULL,
  `simple` varchar(30) NOT NULL,
  PRIMARY KEY (`hash`,`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_ignore`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 24 Lut 2011, 12:27
--

CREATE TABLE IF NOT EXISTS `search_ignore` (
  `word` varchar(30) NOT NULL,
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_index`
--
-- Utworzenie: 24 Lut 2011, 12:27
-- Ostatnia aktualizacja: 09 Maj 2012, 03:01
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `search_index` (
  `object_type` tinyint(4) NOT NULL,
  `cache_id` int(11) NOT NULL,
  `hash` int(10) unsigned NOT NULL,
  `count` tinyint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_type`,`cache_id`,`hash`),
  KEY `object_type` (`object_type`,`hash`,`cache_id`,`count`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_index_times`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 09 Maj 2012, 03:01
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `search_index_times` (
  `object_type` tinyint(4) NOT NULL,
  `object_id` int(11) NOT NULL,
  `last_refresh` datetime NOT NULL,
  PRIMARY KEY (`object_type`,`object_id`),
  KEY `last_refresh` (`last_refresh`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `search_words`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 24 Lut 2011, 12:28
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `search_words` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `word` varchar(255) NOT NULL,
  `simple` varchar(30) NOT NULL,
  `hash` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`,`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `statpics`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `statpics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tplpath` varchar(200) NOT NULL,
  `previewpath` varchar(200) NOT NULL,
  `description` varchar(80) NOT NULL,
  `maxtextwidth` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sysconfig`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 09 Maj 2012, 06:30
--

CREATE TABLE IF NOT EXISTS `sysconfig` (
  `name` varchar(60) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_cron`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 24 Lut 2011, 12:28
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `sys_cron` (
  `name` varchar(60) NOT NULL,
  `last_run` datetime NOT NULL,
  PRIMARY KEY (`name`),
  KEY `last_run` (`last_run`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_logins`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 09 Maj 2012, 07:20
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `sys_logins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `remote_addr` varchar(15) NOT NULL,
  `success` tinyint(1) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `timestamp` (`timestamp`),
  KEY `remote_addr` (`remote_addr`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_menu`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 24 Lut 2011, 12:28
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `sys_menu` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `id_string` varchar(80) NOT NULL,
  `title` varchar(80) NOT NULL,
  `menustring` varchar(80) NOT NULL,
  `access` tinyint(4) NOT NULL,
  `href` varchar(80) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `parent` smallint(6) NOT NULL,
  `position` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_string` (`id_string`),
  KEY `parent` (`parent`,`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_sessions`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 09 Maj 2012, 07:20
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `sys_sessions` (
  `uuid` varchar(36) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permanent` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `last_login` (`last_login`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Triggers `sys_sessions`
--
DROP TRIGGER `ocpl`.`sysSessionsAfterInsert`;
DELIMITER //
CREATE TRIGGER `ocpl`.`sysSessionsAfterInsert` AFTER INSERT ON `ocpl`.`sys_sessions`
 FOR EACH ROW BEGIN 

		UPDATE `user` SET `user`.`last_login`=NEW.`last_login` WHERE `user`.`user_id`=NEW.`user_id`;

	END
//
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sys_temptables`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `sys_temptables` (
  `threadid` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`threadid`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `user`
--
-- Utworzenie: 04 Paź 2011, 15:04
-- Ostatnia aktualizacja: 09 Maj 2012, 07:21
-- Ostatnie sprawdzenie: 04 Paź 2011, 15:04
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) CHARACTER SET utf8 COLLATE utf8_polish_ci DEFAULT NULL,
  `password` varchar(512) DEFAULT NULL,
  `email` varchar(60) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `last_modified` datetime DEFAULT NULL,
  `login_faults` int(11) DEFAULT NULL,
  `last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_login_mobile` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_id` varchar(13) DEFAULT NULL,
  `is_active_flag` int(11) DEFAULT NULL,
  `was_loggedin` int(11) DEFAULT NULL,
  `country` char(2) DEFAULT NULL,
  `pmr_flag` int(11) DEFAULT NULL,
  `new_pw_code` varchar(13) DEFAULT NULL,
  `new_pw_date` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `new_email_code` varchar(13) DEFAULT NULL,
  `new_email_date` int(11) DEFAULT NULL,
  `new_email` varchar(60) DEFAULT NULL,
  `post_news` int(11) DEFAULT NULL,
  `hidden_count` int(11) DEFAULT '0',
  `log_notes_count` int(11) DEFAULT '0',
  `founds_count` int(11) DEFAULT '0',
  `notfounds_count` int(11) DEFAULT '0',
  `uuid` varchar(36) DEFAULT NULL,
  `uuid_mobile` varchar(36) DEFAULT NULL,
  `cache_watches` int(11) DEFAULT NULL,
  `permanent_login_flag` int(11) DEFAULT NULL,
  `watchmail_mode` int(11) NOT NULL DEFAULT '1',
  `watchmail_hour` int(11) NOT NULL DEFAULT '0',
  `watchmail_nextmail` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `watchmail_day` int(11) NOT NULL DEFAULT '0',
  `activation_code` varchar(13) NOT NULL,
  `statpic_logo` int(11) NOT NULL DEFAULT '0',
  `statpic_text` varchar(30) NOT NULL DEFAULT 'Opencaching',
  `cache_ignores` int(11) DEFAULT '0',
  `no_htmledit_flag` tinyint(1) NOT NULL DEFAULT '0',
  `notify_radius` int(11) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `guru` tinyint(1) NOT NULL DEFAULT '0',
  `node` tinyint(4) NOT NULL DEFAULT '0',
  `stat_ban` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(1024) DEFAULT NULL,
  `rules_confirmed` int(1) NOT NULL DEFAULT '0',
  `get_bulletin` tinyint(1) NOT NULL DEFAULT '1',
  `ozi_filips` varchar(255) DEFAULT NULL,
  `hide_flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `notify_radius` (`notify_radius`),
  KEY `username` (`username`),
  KEY `hidden_count` (`hidden_count`),
  KEY `founds_count` (`founds_count`),
  KEY `notfounds_count` (`notfounds_count`),
  KEY `uuid` (`uuid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `watches_notified`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 09 Maj 2012, 07:01
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `watches_notified` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `object_id` int(11) NOT NULL DEFAULT '0',
  `object_type` int(11) NOT NULL DEFAULT '0',
  `date_processed` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`object_id`,`object_type`),
  KEY `object_id` (`object_id`),
  KEY `date_processed` (`date_processed`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `watches_waiting`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 09 Maj 2012, 07:01
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `watches_waiting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `object_id` int(11) NOT NULL DEFAULT '0',
  `object_type` int(11) NOT NULL DEFAULT '0',
  `date_added` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `watchtext` mediumtext NOT NULL,
  `watchtype` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `object_id` (`object_id`),
  KEY `date_added` (`date_added`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `watches_waitingtypes`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `watches_waitingtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `watchtype` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `waypoints`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 08 Maj 2012, 16:03
-- Ostatnie sprawdzenie: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `waypoints` (
  `wp_id` int(11) NOT NULL AUTO_INCREMENT,
  `cache_id` int(11) NOT NULL DEFAULT '0',
  `longitude` double DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `type` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `stage` tinyint(1) NOT NULL DEFAULT '0',
  `desc` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`wp_id`,`cache_id`),
  KEY `cache_id` (`cache_id`),
  KEY `longitude` (`longitude`,`latitude`),
  KEY `latitude` (`latitude`),
  KEY `stage` (`stage`),
  KEY `status` (`status`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='cache waypoints';

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `waypoint_type`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 24 Lut 2011, 12:28
--

CREATE TABLE IF NOT EXISTS `waypoint_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pl` varchar(60) NOT NULL,
  `en` varchar(60) NOT NULL,
  `icon` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `xmlsession`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 09 Maj 2012, 07:13
--

CREATE TABLE IF NOT EXISTS `xmlsession` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `last_use` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `users` int(11) NOT NULL DEFAULT '0',
  `caches` int(11) NOT NULL DEFAULT '0',
  `cachedescs` int(11) NOT NULL DEFAULT '0',
  `cachelogs` int(11) NOT NULL DEFAULT '0',
  `pictures` int(11) NOT NULL DEFAULT '0',
  `removedobjects` int(11) NOT NULL DEFAULT '0',
  `modified_since` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `cleaned` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `xmlsession_data`
--
-- Utworzenie: 24 Lut 2011, 12:28
-- Ostatnia aktualizacja: 09 Maj 2012, 07:13
--

CREATE TABLE IF NOT EXISTS `xmlsession_data` (
  `session_id` int(11) NOT NULL DEFAULT '0',
  `object_type` int(11) NOT NULL DEFAULT '0',
  `object_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`,`object_type`,`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
